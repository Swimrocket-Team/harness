#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
approve-queue.py — очередь одобренных ответов («одна кнопка») и CLI управления ею.

Сюда попадают ТОЛЬКО тексты, которые человек уже одобрил. Негатив сюда не попадает
никогда — он отправляется Верой вручную. Постеры берут текст только из этой очереди
по id: в момент постинга ничего не сочиняется (ноль генерации текста).

Файлы состояния (внутри STATE_ROOT, вне git):
  state/approved_queue.json — сама очередь (id черновика, площадка, текст, статус)
  state/post-log.json       — сколько отправлено по площадкам за сегодня (дневной лимит)
  state/post-freeze         — стоп-кран: файл существует → отправка на паузе

Статус элемента: waiting → posted | failed | skipped; failed|skipped → waiting
(возврат в отправку — «доклейка» после сбоя; из posted возврата нет).

Команды (вывод — РОВНО ОДИН JSON-документ):
  add    --draft-id ID --platform P --source-comment-id CID --category C --text T
         [--anchor «якорь исходного отзыва»]    P: youtube|yandex|2gis|zoon|dzen|manual
         Негатив и любая небезопасная/нераспознанная категория (fail-closed allowlist)
         и повтор source_comment_id отклоняются (код 1).
  list                                        — вся очередь со статусами
  next   [--platform P] [--limit N]           — пачка waiting (лимит + стоп-кран учтены)
  next-one [--platform P]                     — ОДИН элемент для постера (по одному за прогон)
  mark   --draft-id ID --status posted|failed|skipped|waiting [--reason R] [--returned-id ID]
         [--mock]                                — --mock помечает отправку как мок-прогон;
         waiting возвращает failed/skipped-элемент в отправку (из posted — отказ)
  freeze on|off                               — стоп-кран отправки
  purge  [--days 30]                          — удалить posted старше N дней

Коды выхода: 0 — рабочий случай (в т.ч. пусто / стоп-кран / лимит),
1 — отказ add (негатив или дубль), 2 — неправильный вызов.
Окружение: SR_POST_DAILY_LIMIT — дневной лимит на площадку (по умолчанию 10).
"""

import json
import os
import sys
from datetime import datetime, timedelta

PLATFORMS = ("youtube", "yandex", "2gis", "zoon", "dzen", "manual")
DEFAULT_DAILY_LIMIT = 10
# BL-01 (fail-closed): категорию передаёт оркестратор (LLM), поэтому она может прийти
# в любом виде («негативный», «negative-feedback», «тонкий негатив»). Защита очереди —
# явный allowlist безопасных категорий; всё остальное, и всё похожее на негатив
# (префиксно), отклоняется и отправляется Вере вручную.
NEGATIVE_MARKERS = ("negative", "негатив")  # префиксно: «негативный», «negative-feedback»…
SAFE_CATEGORIES = (
    "praise", "похвала",
    "positive", "позитив", "положительный",
    "question", "вопрос",
    "thanks", "спасибо", "благодарность",
    "general", "общее", "общий", "прочее",
    "answer", "ответ",
)


# ---------------------------------------------------------------- окружение --

def state_root():
    return os.environ.get("SR_STATE_ROOT") or os.path.join(
        os.path.expanduser("~"), ".sr-harness", "sr-reputation")


def env_file_path():
    return os.path.join(state_root(), "env")


def load_env_file():
    """Читает env-файл KEY=VALUE. Значения никогда не печатаются."""
    vals = {}
    try:
        with open(env_file_path(), "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key:
                    vals[key] = val
    except OSError:
        pass
    return vals


def get_setting(name):
    val = os.environ.get(name)
    if val:
        return val.strip()
    return (load_env_file().get(name) or "").strip()


# ------------------------------------------------------------- файлы состояния --

def queue_path():
    return os.path.join(state_root(), "state", "approved_queue.json")


def postlog_path():
    return os.path.join(state_root(), "state", "post-log.json")


def freeze_path():
    return os.path.join(state_root(), "state", "post-freeze")


def _atomic_write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def load_queue():
    try:
        with open(queue_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("items"), list):
            return data
    except (OSError, ValueError):
        pass
    return {"items": []}


def save_queue(queue):
    _atomic_write(queue_path(), queue)


def load_postlog():
    try:
        with open(postlog_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("days"), dict):
            return data
    except (OSError, ValueError):
        pass
    return {"days": {}}


def save_postlog(postlog):
    _atomic_write(postlog_path(), postlog)


# ------------------------------------------------------------------- утилиты --

def emit(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def fail_usage(msg, hint):
    """Неправильный вызов — код 2."""
    emit({"error": msg, "human_hint": hint})
    sys.exit(2)


def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def today_str():
    return datetime.now().astimezone().strftime("%Y-%m-%d")


def daily_limit():
    raw = get_setting("SR_POST_DAILY_LIMIT")
    try:
        return int(raw) if raw else DEFAULT_DAILY_LIMIT
    except ValueError:
        return DEFAULT_DAILY_LIMIT


def is_frozen():
    return os.path.exists(freeze_path())


def posted_today(platform):
    postlog = load_postlog()
    return int(postlog["days"].get(today_str(), {}).get(platform, 0))


def bump_posted(platform):
    postlog = load_postlog()
    day = postlog["days"].setdefault(today_str(), {})
    day[platform] = int(day.get(platform, 0)) + 1
    # держим счётчики за последние 90 дней, файл не растёт бесконечно
    cutoff = (datetime.now().astimezone() - timedelta(days=90)).strftime("%Y-%m-%d")
    postlog["days"] = {d: v for d, v in sorted(postlog["days"].items()) if d >= cutoff}
    save_postlog(postlog)


def find_item(queue, draft_id):
    for item in queue["items"]:
        if item.get("draft_id") == draft_id:
            return item
    return None


# ------------------------------------------------------------- команды CLI --

def cmd_add(rest):
    opts = parse_opts(rest, {"--draft-id": "draft_id", "--platform": "platform",
                             "--source-comment-id": "source_comment_id",
                             "--category": "category", "--text": "text",
                             "--anchor": "anchor"}, required=("draft_id", "platform",
                                                              "source_comment_id",
                                                              "category", "text"))
    if opts["platform"] not in PLATFORMS:
        fail_usage("неизвестная площадка: %s" % opts["platform"],
                   "Площадка — одна из: %s." % ", ".join(PLATFORMS))

    category = opts["category"].strip().lower()
    is_negative = any(category.startswith(marker) for marker in NEGATIVE_MARKERS)
    if is_negative or category not in SAFE_CATEGORIES:
        # Негатив и нераспознанное — вне кнопки отправки, всегда (fail-closed).
        emit({
            "status": "rejected",
            "reason": "negative" if is_negative else "unknown_category",
            "human_hint": ("Негатив отправляется только Верой вручную — в очередь "
                           "автопубликации он не попадает. Черновик ответа остаётся "
                           "у тебя для передачи Вере." if is_negative else
                           "Категория «%s» не входит в список безопасных, поэтому в очередь "
                           "автопубликации я её не добавляю: всё нераспознанное отправляется "
                           "Верой вручную, как и негатив. Если категория точно безопасная — "
                           "пусть Миша добавит её в SAFE_CATEGORIES в approve-queue.py."
                           % category),
        })
        sys.exit(1)

    queue = load_queue()
    for item in queue["items"]:
        if item.get("source_comment_id") == opts["source_comment_id"]:
            emit({
                "status": "rejected",
                "reason": "duplicate",
                "draft_id": item.get("draft_id"),
                "human_hint": ("Ответ на этот отзыв уже в очереди (%s, статус: %s) — "
                               "дублей не создаём." % (item.get("draft_id"),
                                                       item.get("status"))),
            })
            sys.exit(1)
    if find_item(queue, opts["draft_id"]) is not None:
        emit({
            "status": "rejected",
            "reason": "duplicate_draft",
            "draft_id": opts["draft_id"],
            "human_hint": "Черновик с таким id уже в очереди — второй раз не добавляем.",
        })
        sys.exit(1)

    item = {
        "draft_id": opts["draft_id"],
        "platform": opts["platform"],
        "source_comment_id": opts["source_comment_id"],
        "category": category,
        "text": opts["text"],
        "anchor": opts.get("anchor"),
        "status": "waiting",
        "added_at": now_iso(),
        "posted_at": None,
        "returned_id": None,
        "note": None,
        "mock": False,
    }
    queue["items"].append(item)
    save_queue(queue)
    emit(item)
    sys.exit(0)


def cmd_list(rest):
    queue = load_queue()
    counts = {p: posted_today(p) for p in PLATFORMS}  # один проход по post-log (IN-10)
    emit({
        "frozen": is_frozen(),
        "daily_limit": daily_limit(),
        "posted_today": {p: n for p, n in counts.items() if n},
        "items": queue["items"],
    })
    sys.exit(0)


def queue_batch(platform=None):
    """Пачка waiting с учётом стоп-крана и дневного лимита на площадку."""
    result = {"frozen": is_frozen(), "items": [], "limit_reached": []}
    queue = load_queue()
    waiting = sum(1 for item in queue["items"]
                  if item.get("status") == "waiting"
                  and (not platform or item.get("platform") == platform))
    result["remaining_waiting"] = waiting
    if result["frozen"]:
        result["status"] = "frozen"
        result["human_hint"] = ("Отправка на паузе — включён стоп-кран (осталось waiting: "
                                "%d). Скажи «доклеить», когда будешь готова продолжить."
                                % waiting)
        return result
    limit = daily_limit()
    for item in queue["items"]:
        if item.get("status") != "waiting":
            continue
        if platform and item.get("platform") != platform:
            continue
        if posted_today(item["platform"]) >= limit:
            if item["platform"] not in result["limit_reached"]:
                result["limit_reached"].append(item["platform"])
            continue
        result["items"].append(item)
    if not result["items"]:
        if result["limit_reached"]:
            result["status"] = "limit_reached"
            result["human_hint"] = ("Дневной лимит отправок на %s исчерпан (%d в день) — "
                                    "остальное отправится завтра или после решения человека."
                                    % (" / ".join(result["limit_reached"]), limit))
        else:
            result["status"] = "empty"
            result["human_hint"] = "В очереди нет ничего ждущего отправки."
    return result


def cmd_next(rest):
    # --limit парсится независимо от --platform (IN-02): раньше «next --limit 1»
    # молча отдавал всю пачку.
    opts = parse_opts(rest, {"--platform": "platform", "--limit": "limit"}, ())
    platform = opts.get("platform")
    if platform and platform not in PLATFORMS:
        fail_usage("неизвестная площадка: %s" % platform,
                   "Площадка — одна из: %s." % ", ".join(PLATFORMS))
    max_items = None
    if opts.get("limit"):
        try:
            max_items = int(opts["limit"])
        except ValueError:
            fail_usage("флагу --limit нужно число", "Пример: next --limit 5.")
    result = queue_batch(platform)
    if max_items is not None:
        result["items"] = result["items"][:max_items]
    emit(result)
    sys.exit(0)


def cmd_next_one(rest):
    platform = None
    if rest:
        opts = parse_opts(rest, {"--platform": "platform"}, ())
        platform = opts.get("platform")
        if platform and platform not in PLATFORMS:
            fail_usage("неизвестная площадка: %s" % platform,
                       "Площадка — одна из: %s." % ", ".join(PLATFORMS))
    result = queue_batch(platform)
    if result["items"]:
        emit(result["items"][0])
    else:
        emit({k: v for k, v in result.items() if k != "items"})
    sys.exit(0)


def cmd_mark(rest):
    mock = "--mock" in rest          # булев флаг, без значения
    rest = [a for a in rest if a != "--mock"]
    opts = parse_opts(rest, {"--draft-id": "draft_id", "--status": "status",
                             "--reason": "reason", "--returned-id": "returned_id"},
                      required=("draft_id", "status"))
    if opts["status"] not in ("posted", "failed", "skipped", "waiting"):
        fail_usage("неизвестный статус: %s" % opts["status"],
                   "Статус — posted, failed, skipped или waiting (возврат в отправку).")
    queue = load_queue()
    item = find_item(queue, opts["draft_id"])
    if item is None:
        fail_usage("в очереди нет элемента с draft_id=%s" % opts["draft_id"],
                   "Посмотри id командой: approve-queue.py list.")
    if opts["status"] == "waiting" and item.get("status") == "posted":
        # Отправленное не отзывается — иначе постер смог бы взять его повторно.
        fail_usage("элемент уже отправлен — возврат в waiting невозможен",
                   "Статус posted финальный; для повторной отправки нужен новый черновик.")
    if item.get("status") == "posted":
        # Повторная отметка posted не считается второй отправкой (защита от дублей).
        out = dict(item)
        out["already_posted"] = True
        emit(out)
        sys.exit(0)
    item["status"] = opts["status"]
    item["note"] = opts.get("reason")
    if mock:
        item["mock"] = True
    if opts["status"] == "waiting":
        # Возврат в отправку: следы прошлой (неудачной) попытки сбрасываем.
        item["posted_at"] = None
        item["returned_id"] = None
    if opts["status"] == "posted":
        item["posted_at"] = now_iso()
        item["returned_id"] = opts.get("returned_id")
        bump_posted(item["platform"])
    save_queue(queue)
    emit(item)
    sys.exit(0)


def cmd_freeze(rest):
    if len(rest) != 1 or rest[0] not in ("on", "off"):
        fail_usage("использование: freeze on|off",
                   "freeze on — включить стоп-кран, freeze off — снять.")
    if rest[0] == "on":
        os.makedirs(os.path.dirname(freeze_path()), exist_ok=True)
        with open(freeze_path(), "w", encoding="utf-8") as f:
            f.write(now_iso() + "\n")
        emit({"frozen": True,
              "human_hint": "Стоп-кран включён: отправка приостановлена. "
                            "Снять: freeze off (или скажи «доклеить» в скилле)."})
    else:
        try:
            os.remove(freeze_path())
        except OSError:
            pass
        emit({"frozen": False, "human_hint": "Стоп-кран снят: отправка снова работает."})
    sys.exit(0)


def cmd_purge(rest):
    days = 30
    if rest:
        opts = parse_opts(rest, {"--days": "days"}, ())
        if opts.get("days"):
            try:
                days = int(opts["days"])
            except ValueError:
                fail_usage("флагу --days нужно число", "Пример: purge --days 30.")
    queue = load_queue()
    cutoff = datetime.now().astimezone() - timedelta(days=days)
    kept, removed = [], 0
    for item in queue["items"]:
        if item.get("status") == "posted" and item.get("posted_at"):
            try:
                old = datetime.fromisoformat(item["posted_at"])
            except ValueError:
                old = None
            if old and old < cutoff:
                removed += 1
                continue
        kept.append(item)
    queue["items"] = kept
    save_queue(queue)
    emit({"purged": removed, "kept": len(kept),
          "human_hint": "Убрано отправленных старше %d дн.: %d." % (days, removed)})
    sys.exit(0)


# -------------------------------------------------------------------- разбор --

def parse_opts(rest, flags, required):
    """Парсит пары --флаг значение. Незнакомый флаг или нехватка — код 2."""
    opts = {}
    rest = list(rest)
    while rest:
        arg = rest.pop(0)
        if arg not in flags:
            fail_usage("неизвестный флаг: %s" % arg,
                       "Допустимые флаги: %s." % ", ".join(sorted(flags)))
        if not rest:
            fail_usage("флагу %s нужно значение" % arg, "Проверь команду.")
        opts[flags[arg]] = rest.pop(0)
    for key in required:
        if not opts.get(key):
            fail_usage("не хватает --%s" % key.replace("_", "-"),
                       "Смотри шапку файла — там все команды и флаги.")
    return opts


COMMANDS = {
    "add": cmd_add,
    "list": cmd_list,
    "next": cmd_next,
    "next-one": cmd_next_one,
    "mark": cmd_mark,
    "freeze": cmd_freeze,
    "purge": cmd_purge,
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        fail_usage("команда не задана или неизвестна",
                   "Команды: %s. Подробности — в шапке файла." % ", ".join(COMMANDS))
    COMMANDS[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    main()
