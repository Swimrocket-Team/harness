#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
monitor-mail.py — мониторинг писем-уведомлений площадок в служебном ящике
школы SwimRocket (для шага 0 режима «утро» скилла /sr-reputation).

Только стандартная библиотека Python 3 — ноль pip-зависимостей.

Ключи — только из окружения, никогда не в коде:
  SR_MAIL_USER — адрес служебного ящика (swwimrocketasisstant@gmail.com)
  SR_MAIL_PASS — пароль приложения Gmail (app password), НЕ обычный пароль.
Переменные можно передать в процессе ИЛИ записать в env-файл состояния:
  $SR_STATE_ROOT/env, по умолчанию ~/.sr-harness/sr-reputation/env (формат KEY=VALUE).

Что делает:
  1. IMAP imap.gmail.com:993 (SSL), папка INBOX (только чтение — писья не
     помечаются прочитанными).
  2. Ищет письма за последние 14 дней, у которых в АДРЕСЕ отправителя встречается
     yandex | 2gis | zoon | google (уведомления площадок о новых отзывах).
  3. Парсит тему и текст (plaintext; html -> грубое извлечение текста).
  4. Классифицирует площадку по домену отправителя; не опозналась — явная
     пометка platform: "unrecognized".
  5. Дедупликация по Message-ID через seen.json.

Вывод в stdout — всегда РОВНО ОДИН JSON-документ:
  успех        -> [{source, platform, from, subject, text_excerpt,
                    message_id, date}, ...]  (пустой массив = нет нового)
  нет ключей   -> {"status": "not_configured", "human_hint": "..."}
  ошибка       -> {"error": "...", "human_hint": "..."}

Код выхода — 0 во всех рабочих случаях (not_configured и ошибка — не падение:
«утро» должно продолжаться в ручном режиме).

Флаги:
  --dry-run        показать, что нашлось, но НЕ обновлять seen.json.
  --include-spam   дополнительно просмотреть папку «Спам», если она найдена
                   (задел: по умолчанию спам не проверяется).
  --days N         глубина поиска в днях (по умолчанию 14).
"""

import email
import email.policy
import hashlib
import html as html_mod
import imaplib
import json
import os
import re
import sys
from datetime import datetime, timedelta

IMAP_HOST = "imap.gmail.com"
IMAP_PORT = 993
DEFAULT_DAYS = 14
EXCERPT_LEN = 600
SEEN_KEEP = 5000

# Порядок важен: сначала более специфичные домены, потом общие.
PLATFORM_RULES = [
    ("2gis", "2gis"),
    ("zoon", "zoon"),
    ("yandex", "yandex"),
    ("google", "google"),
]
SENDER_FILTER = re.compile(r"yandex|2gis|zoon|google", re.IGNORECASE)

# Месяцы для IMAP SEARCH SINCE — всегда латиницей независимо от локали.
IMAP_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


# ---------------------------------------------------------------- окружение --

def state_root():
    return os.environ.get("SR_STATE_ROOT") or os.path.join(
        os.path.expanduser("~"), ".sr-harness", "sr-reputation")


def env_file_path():
    return os.path.join(state_root(), "env")


def load_env_file():
    """Читает env-файл KEY=VALUE. Никогда не печатает значения."""
    vals = {}
    try:
        with open(env_file_path(), "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key:
                    vals[key] = val
    except OSError:
        pass
    return vals


def get_cred(name):
    val = os.environ.get(name)
    if val:
        return val.strip()
    return (load_env_file().get(name) or "").strip()


def seen_path():
    return os.path.join(state_root(), "state", "seen.json")


def load_seen():
    try:
        with open(seen_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {}


def save_seen(seen):
    # Атомарная запись (WR-03): обрыв посреди записи не оставит битый JSON —
    # иначе следующий прогон молча потеряет весь дедуп и переотчитает всё накопленное.
    path = seen_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(seen, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


# ------------------------------------------------------------------- вывод --

def sanitize(text, *secrets):
    for s in secrets:
        if s and s in text:
            text = text.replace(s, "***")
    return text


def emit(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def not_configured():
    emit({
        "status": "not_configured",
        "human_hint": ("Мониторинг почты не настроен: нет SR_MAIL_USER / SR_MAIL_PASS "
                       "(их один раз записывает Миша в ~/.sr-harness/sr-reputation/env). "
                       "Работаем как раньше — данные принесёт человек."),
    })
    sys.exit(0)


def fail(error, human_hint, *secrets):
    emit({"error": sanitize(error, *secrets), "human_hint": human_hint})
    sys.exit(0)


# ------------------------------------------------------------------ письмо --

def extract_address(from_header):
    """Адрес из заголовка From: содержимое <...>, иначе сам заголовок (lowercase)."""
    # Адрес может быть в угловых скобках: "Яндекс Бизнес <noreply@yandex.ru>"
    match = re.search(r"<([^>]+)>", from_header or "")
    return (match.group(1) if match else (from_header or "")).strip().lower()


def classify_platform(from_header):
    """Площадка по домену отправителя; не опозналась -> unrecognized."""
    domain = extract_address(from_header).rpartition("@")[2]
    for needle, platform in PLATFORM_RULES:
        if needle in domain:
            return platform
    return "unrecognized"


def _decode_part(part):
    """Декодирует часть письма с учётом charset; get_payload(decode=True)
    работает и на EmailMessage, и на legacy-объектах (в отличие от get_content)."""
    payload = part.get_payload(decode=True)
    if payload is None:
        return None
    charset = part.get_content_charset() or "utf-8"
    try:
        return payload.decode(charset, "replace")
    except (LookupError, UnicodeDecodeError):
        return payload.decode("utf-8", "replace")


def extract_body(msg):
    """Текст письма: предпочитаем text/plain, иначе грубо вычищаем text/html."""
    plain = None
    html_text = None
    for part in msg.walk():
        if part.get_content_disposition() == "attachment":
            continue
        ctype = part.get_content_type()
        if ctype == "text/plain" and plain is None:
            plain = _decode_part(part)
        elif ctype == "text/html" and html_text is None:
            html_text = _decode_part(part)
    text = plain
    if not text and html_text:
        text = re.sub(r"<(script|style)\b[^>]*>.*?</\1>", " ", html_text,
                      flags=re.IGNORECASE | re.DOTALL)
        text = re.sub(r"<[^>]+>", " ", text)
        text = html_mod.unescape(text)
    if not text:
        return ""
    return re.sub(r"[ \t]*\n[ \t]*", "\n", text).strip()


def stable_message_id(msg, from_header, subject, date_header):
    mid = (msg.get("Message-ID") or msg.get("Message-Id") or "").strip()
    if mid:
        return mid
    raw = "%s|%s|%s" % (from_header, date_header, subject)
    return "<generated-%s@sr-monitor>" % hashlib.sha1(raw.encode("utf-8")).hexdigest()


def search_folder(imap, folder, since_date, user, password):
    """Возвращает список распарсенных писем из папки, попавших под фильтр."""
    try:
        status, _ = imap.select(folder, readonly=True)
        if status != "OK":
            return None  # папки нет / не открывается — не ошибка прогона
    except imaplib.IMAP4.error:
        return None

    status, data = imap.search(None, 'SINCE', '"%s"' % since_date)
    if status != "OK":
        return []
    messages = []
    for num in data[0].split():
        status, msg_data = imap.fetch(num, "(RFC822)")
        if status != "OK" or not msg_data or msg_data[0] is None:
            continue
        raw = msg_data[0][1]
        try:
            msg = email.message_from_bytes(raw, policy=email.policy.default)
        except Exception:
            continue
        from_header = str(msg.get("From") or "")
        # Фильтр отправителя — по АДРЕСУ, а не по всему заголовку (IN-06):
        # display name «Yandex Club» не должен протаскивать постороннюю рассылку.
        if not SENDER_FILTER.search(extract_address(from_header)):
            continue
        subject = str(msg.get("Subject") or "")
        date_header = str(msg.get("Date") or "")
        mid = stable_message_id(msg, from_header, subject, date_header)
        body = extract_body(msg)
        excerpt = body[:EXCERPT_LEN] + ("…" if len(body) > EXCERPT_LEN else "")
        messages.append({
            "source": "mail",
            "platform": classify_platform(from_header),
            "from": from_header,
            "subject": subject,
            "text_excerpt": excerpt,
            "message_id": mid,
            "date": date_header,
        })
    return messages


# --------------------------------------------------------------------- main --

def parse_flags(args):
    dry_run = False
    include_spam = False
    days = DEFAULT_DAYS
    rest = list(args)
    while rest:
        arg = rest.pop(0)
        if arg == "--dry-run":
            dry_run = True
        elif arg == "--include-spam":
            include_spam = True
        elif arg == "--days":
            if not rest:
                fail("флагу --days нужно число", "Запусти без флагов или с --days 14.")
            try:
                days = int(rest.pop(0))
            except ValueError:
                fail("флагу --days нужно число", "Запусти без флагов или с --days 14.")
        else:
            fail("неизвестный флаг: %s" % arg,
                 "Допустимые флаги: --dry-run, --include-spam, --days N.")
    return dry_run, include_spam, days


def main():
    user = get_cred("SR_MAIL_USER")
    password = get_cred("SR_MAIL_PASS")
    if not user or not password:
        not_configured()

    dry_run, include_spam, days = parse_flags(sys.argv[1:])

    since_dt = datetime.now() - timedelta(days=days)
    since_date = "%02d-%s-%d" % (since_dt.day, IMAP_MONTHS[since_dt.month - 1], since_dt.year)

    try:
        imap = imaplib.IMAP4_SSL(IMAP_HOST, IMAP_PORT)
        try:
            imap.login(user, password)
        except imaplib.IMAP4.error as exc:
            fail("IMAP: вход не прошёл: %s" % sanitize(str(exc), user, password),
                 "Ящик не принял логин или пароль приложения. Напомни Мише проверить "
                 "SR_MAIL_USER и SR_MAIL_PASS (нужен пароль приложения Gmail, 16 символов, "
                 "и включённый IMAP в настройках ящика).")

        found = search_folder(imap, "INBOX", since_date, user, password) or []
        if include_spam:
            # Ищем папку спама (Gmail называет её [Google Mail]/Spam или INBOX/Spam).
            spam_folder = None
            try:
                status, folders = imap.list()
                if status == "OK":
                    for line in folders or []:
                        name = line.decode("utf-8", "replace")
                        # \X в python-re невалиден (WR-02) — ищем имя папки как
                        # содержимое кавычек, заканчивающееся на Spam.
                        match = re.search(r'"([^"]*Spam)"', name, re.IGNORECASE)
                        if match:
                            spam_folder = match.group(1)
                            break
            except imaplib.IMAP4.error:
                pass
            if spam_folder:
                spam = search_folder(imap, spam_folder, since_date, user, password)
                if spam:
                    found.extend(spam)

        try:
            imap.logout()
        except imaplib.IMAP4.error:
            pass
    except (imaplib.IMAP4.error, OSError, EOFError) as exc:
        fail("нет связи с почтовым сервером: %s" % sanitize(str(exc), user, password),
             "Не получилось связаться с Gmail. Проверь интернет и попробуй ещё раз; "
             "если не проходит — работаем как раньше и напомни Мише.")

    seen = load_seen()
    seen_ids = set(seen.get("mail", []))
    results = []
    new_ids = []
    for item in found:
        mid = item["message_id"]
        if mid in seen_ids:
            continue
        seen_ids.add(mid)
        new_ids.append(mid)
        results.append(item)

    if new_ids and not dry_run:
        seen["mail"] = (seen.get("mail", []) + new_ids)[-SEEN_KEEP:]
        save_seen(seen)

    emit(results)
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:  # контракт «ровно один JSON» даже при неожиданном сбое
        fail("неожиданная ошибка: %r" % exc,
             "Что-то сломалось в самом скрипте мониторинга почты — сообщи Мише и "
             "пришли ему этот ответ целиком.",
             get_cred("SR_MAIL_USER"), get_cred("SR_MAIL_PASS"))
