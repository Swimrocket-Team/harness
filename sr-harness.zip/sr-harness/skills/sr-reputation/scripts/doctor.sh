#!/usr/bin/env bash
#
# doctor.sh — проверка ассистента «Репутация» простым языком.
# Печатает по пунктам ОК / ПРОБЛЕМА + ЧТО ДЕЛАТЬ и общий итог.
#
# ВАЖНО: никогда не печатает значения ключей и паролей — только статусы.
# Запуск двойным кликом — через doctor.command рядом с этим файлом.

set -u

STATE_ROOT="${SR_STATE_ROOT:-$HOME/.sr-harness/sr-reputation}"
ENV_FILE="$STATE_ROOT/env"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"

OK_COUNT=0
PROBLEMS=0

ok() {
  echo "  ОК: $1"
  OK_COUNT=$((OK_COUNT + 1))
}

problem() {
  echo "  ПРОБЛЕМА: $1"
  echo "    ЧТО ДЕЛАТЬ: ${2:-см. README-СТАРТ.md или напиши Мише}"
  PROBLEMS=$((PROBLEMS + 1))
}

note() {
  echo "  заметка: $1"
}

env_has_value() {
  # Есть ли у переменной в env-файле непустое значение — тем же парсером, что и
  # в рантайме (срезаются пробелы и кавычки), а не grep'ом: «VAR=""» grep считал
  # непустым, а «VAR = значение» — наоборот (IN-04).
  SR_ENV_FILE="$ENV_FILE" SR_ENV_VAR="$1" python3 - <<'DOCTOR_ENV_PY'
import os, sys
path, var = os.environ["SR_ENV_FILE"], os.environ["SR_ENV_VAR"]
try:
    value = ""
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            if key.strip() == var:
                value = val.strip().strip('"').strip("'")
                break
    sys.exit(0 if value else 1)
except OSError:
    sys.exit(1)
DOCTOR_ENV_PY
}

echo "Проверка ассистента «Репутация»"
echo "==============================="
echo ""

# --- 1. Программа Python (движок) -------------------------------------------
if command -v python3 >/dev/null 2>&1; then
  ok "Программа, на которой работает ассистент (Python), установлена."
else
  problem "Не найдена программа Python 3 — без неё ассистент не сможет проверять отзывы."
fi

# --- 2. Установлен ли ассистент ---------------------------------------------
SKILL_FOUND=""
for HOST_DIR in "$HOME/.zcode/skills/sr-reputation" "$HOME/.claude/skills/sr-reputation"; do
  if [ -f "$HOST_DIR/SKILL.md" ]; then
    SKILL_FOUND="$HOST_DIR"
    break
  fi
done
if [ -n "$SKILL_FOUND" ]; then
  ok "Ассистент установлен ($SKILL_FOUND)."
else
  problem "Ассистент ещё не установлен в Claude Code / Z-Code."
fi

# --- 3. Файл настроек мониторинга -------------------------------------------
MISSING_VARS=""
if [ ! -f "$ENV_FILE" ]; then
  problem "Настройки мониторинга не записаны (нет файла настроек)." \
          "напиши Мише «настрой мониторинг» — он запишет ключи один раз."
else
  for VAR in SR_YT_API_KEY SR_MAIL_USER SR_MAIL_PASS; do
    # Печатаем только ИМЯ переменной и есть ли значение, само значение не выводим.
    if ! env_has_value "$VAR"; then
      MISSING_VARS="$MISSING_VARS $VAR"
    fi
  done
  if [ -z "$MISSING_VARS" ]; then
    ok "Настройки мониторинга записаны (все три)."
  else
    problem "В настройках мониторинга не хватает:${MISSING_VARS}"
    echo "    ЧТО ДЕЛАТЬ: напиши Мише — он допишет недостающее в файл $ENV_FILE."
  fi
  PERMS=$(stat -f '%Lp' "$ENV_FILE" 2>/dev/null || echo "")
  if [ -n "$PERMS" ] && [ "$PERMS" != "600" ]; then
    note "права на файл настроек шире, чем нужно ($PERMS вместо 600); Миша может исправить командой chmod 600."
  fi
fi

# --- 4. Проверка ключа YouTube (лёгкий запрос) -------------------------------
if [ -f "$ENV_FILE" ] && env_has_value SR_YT_API_KEY; then
  RESULT=$(SR_ENV_FILE="$ENV_FILE" python3 - <<'DOCTOR_PY'
import json, os, sys, urllib.parse, urllib.request

env_file = os.environ["SR_ENV_FILE"]
key = ""
try:
    with open(env_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("SR_YT_API_KEY="):
                key = line.partition("=")[2].strip().strip('"').strip("'")
                break
except OSError:
    print("FAIL|не удалось прочитать файл настроек")
    sys.exit(0)

if not key:
    print("FAIL|ключ не найден в файле настроек")
    sys.exit(0)

url = ("https://www.googleapis.com/youtube/v3/channels?" +
       urllib.parse.urlencode({"part": "id", "forHandle": "swim_rocket",
                               "maxResults": 1, "key": key}))
try:
    with urllib.request.urlopen(url, timeout=20) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if data.get("items"):
        print("OK|ключ YouTube работает, канал школы найден")
    else:
        print("FAIL|ключ принят, но канал @swim_rocket не найден — напиши Мише")
except urllib.error.HTTPError as exc:
    reason = ""
    try:
        body = json.loads(exc.read().decode("utf-8"))
        reasons = body.get("error", {}).get("errors", []) or [{}]
        reason = reasons[0].get("reason", "")
    except Exception:
        pass
    if "quota" in reason.lower():
        print("OK|лимит запросов YouTube на сегодня исчерпан — это не поломка, проверь завтра")
    else:
        print("FAIL|YouTube не принял ключ (%s %s) — проверь, что ключ скопирован целиком, и что включён YouTube Data API" % (exc.code, reason))
except Exception:
    print("FAIL|нет связи с YouTube — проверь интернет")
DOCTOR_PY
)
  case "$RESULT" in
    "FAIL|"*) STATUS="FAIL"; MESSAGE="${RESULT#FAIL|}";;
    "OK|"*)   STATUS="OK";   MESSAGE="${RESULT#OK|}";;
    *)        STATUS="FAIL"; MESSAGE="неожиданный результат проверки";;
  esac
  if [ "$STATUS" = "OK" ]; then
    ok "$MESSAGE"
  else
    problem "Проверка YouTube не прошла: $MESSAGE" \
            "напиши Мише «не работает ключ YouTube»."
  fi
else
  note "ключ YouTube не проверялся — его ещё нет в настройках (это уже учтено выше)."
fi

# --- 5. Проверка почты (вход по IMAP) ----------------------------------------
if [ -f "$ENV_FILE" ] && env_has_value SR_MAIL_USER && env_has_value SR_MAIL_PASS; then
  RESULT=$(SR_ENV_FILE="$ENV_FILE" python3 - <<'DOCTOR_PY2'
import imaplib, os, sys

env_file = os.environ["SR_ENV_FILE"]
user = password = ""
try:
    with open(env_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("SR_MAIL_USER="):
                user = line.partition("=")[2].strip().strip('"').strip("'")
            elif line.startswith("SR_MAIL_PASS="):
                password = line.partition("=")[2].strip().strip('"').strip("'")
except OSError:
    print("FAIL|не удалось прочитать файл настроек")
    sys.exit(0)

if not user or not password:
    print("FAIL|логин или пароль не найдены в файле настроек")
    sys.exit(0)

try:
    imap = imaplib.IMAP4_SSL("imap.gmail.com", 993)
    imap.login(user, password)
    imap.logout()
    print("OK|почта подключается, вход проходит")
except imaplib.IMAP4.error:
    print("FAIL|почта не принимает логин или пароль — проверь, что это пароль приложения (16 символов), и что в Gmail включён IMAP")
except Exception:
    print("FAIL|нет связи с Gmail — проверь интернет")
DOCTOR_PY2
)
  case "$RESULT" in
    "FAIL|"*) STATUS="FAIL"; MESSAGE="${RESULT#FAIL|}";;
    "OK|"*)   STATUS="OK";   MESSAGE="${RESULT#OK|}";;
    *)        STATUS="FAIL"; MESSAGE="неожиданный результат проверки";;
  esac
  if [ "$STATUS" = "OK" ]; then
    ok "$MESSAGE"
  else
    problem "Проверка почты не прошла: $MESSAGE" \
            "напиши Мише «не работает почта мониторинга»."
  fi
else
  note "почта не проверялась — логина/пароля ещё нет в настройках (это уже учтено выше)."
fi

# --- 6. Автоответы (постинг одобренных) ---------------------------------------
# Это ОПЦИЯ: ничего не настроено — норма (заметка, не ПРОБЛЕМА). Настроено и сломано — ПРОБЛЕМА.
echo ""
echo "Автоответы (отправка одобренных ответов)"
echo "----------------------------------------"
POST_BROKEN=0

# 6.1 OAuth-токен YouTube
if [ -f "$ENV_FILE" ] && env_has_value SR_YT_OAUTH_TOKEN; then
  if env_has_value SR_YT_OAUTH_CLIENT_ID && env_has_value SR_YT_OAUTH_CLIENT_SECRET; then
    ok "Токен YouTube для автоответов записан (проверку отправки делает пробная пачка)."
  else
    problem "Токен YouTube записан, но не хватает настроек OAuth-клиента (SR_YT_OAUTH_CLIENT_ID / SR_YT_OAUTH_CLIENT_SECRET)." \
            "напиши Мише «дозаполни OAuth YouTube»."
    POST_BROKEN=$((POST_BROKEN + 1))
  fi
else
  note "токена YouTube для автоответов нет — это нормально: автоответы подключит Вера, скажи Мише когда."
fi

# 6.2 Playwright (браузер для Яндекс.Бизнес / 2ГИС / Zoon)
SESSIONS_FOUND=""
for P in yandex 2gis zoon; do
  if [ -f "$STATE_ROOT/sessions/$P.json" ]; then
    if python3 -c "import json,sys; json.load(open(sys.argv[1], encoding='utf-8'))" "$STATE_ROOT/sessions/$P.json" >/dev/null 2>&1; then
      SESSIONS_FOUND="$SESSIONS_FOUND $P"
    else
      problem "Файл сессии $P повреждён (не читается)." \
              "подключи сессию заново по сценарию подключения или напиши Мише."
      POST_BROKEN=$((POST_BROKEN + 1))
    fi
  fi
done

if python3 -c "import playwright" >/dev/null 2>&1; then
  ok "Программа-браузер для площадок (Playwright) установлена."
else
  if [ -n "$SESSIONS_FOUND" ]; then
    problem "Сессии площадок записаны, но программа-браузер (Playwright) не установлена — отправка не сможет пройти." \
            "открой Терминал и выполни две команды: python3 -m pip install playwright, затем python3 -m playwright install chromium (или напиши Мише)."
    POST_BROKEN=$((POST_BROKEN + 1))
  else
    note "программа-браузер (Playwright) не установлена — это нормально: понадобится, когда Вера подключит сессии кабинетов."
  fi
fi

# 6.3 Сессии площадок
if [ -n "$SESSIONS_FOUND" ]; then
  ok "Сессии кабинетов записаны:${SESSIONS_FOUND}"
else
  note "сессий кабинетов (Яндекс.Бизнес / 2ГИС / Zoon) нет — это нормально: автоответы на площадках подключит Вера, скажи Мише когда."
fi

if [ "$POST_BROKEN" = "0" ]; then
  echo "  Автоответы: если всё выше — только заметки, это норма до подключения доступов."
fi

# --- Итог --------------------------------------------------------------------
echo ""
if [ "$PROBLEMS" = "0" ]; then
  echo "ИТОГ: всё готово. Открой Claude Code (или Z-Code), набери /sr-reputation и нажми Enter."
else
  echo "ИТОГ: нашлись проблемы — исправь пункты, где написано ПРОБЛЕМА (выше есть ЧТО ДЕЛАТЬ)."
  echo "Если что-то непонятно — напиши Мише и пришли ему всё, что напечатало это окно."
fi
exit 0
