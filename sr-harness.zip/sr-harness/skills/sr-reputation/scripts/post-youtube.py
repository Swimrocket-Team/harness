#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
post-youtube.py — постер одобренного ответа на YouTube (только из очереди).

Берёт ОДИН элемент очереди (approve-queue.py next-one, platform=youtube) и отвечает
на комментарий через официальный YouTube Data API (comments.insert). Текст берётся
ТОЛЬКО из элемента очереди — в момент постинга ничего не сочиняется (ноль LLM-вызовов).

Доступы — только из окружения, никогда не в коде:
  SR_YT_OAUTH_TOKEN        — refresh-токен владельца канала (подключит Вера в Phase 6)
  SR_YT_OAUTH_CLIENT_ID    — OAuth-клиент Google Cloud проекта школы
  SR_YT_OAUTH_CLIENT_SECRET
(передаются в процессе ИЛИ лежат в env-файле $SR_STATE_ROOT/env, формат KEY=VALUE).

Вывод в stdout — РОВНО ОДИН JSON-документ; код выхода 0 во всех рабочих случаях
(not_configured / пусто / стоп-кран / лимит / ошибка API — не падение). Код 2 —
только неправильный вызов.

Флаги:
  --next-from-queue     взять следующий waiting-элемент ютуба из очереди (основной режим)
  --draft-id ID         взять из очереди конкретный элемент (вместо next-from-queue)
  --mock                мок-прогон: без сети и токена; помечает элемент как posted (mock)
  --sleep-after N       подождать N секунд после отправки (для автономных прогонов;
                        в скилле паузу 30–60 сек держит оркестратор)
"""

import contextlib
import importlib.util
import io
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

API_BASE = "https://www.googleapis.com/youtube/v3"
TOKEN_URL = "https://oauth2.googleapis.com/token"
REQUIRED_ENV = ("SR_YT_OAUTH_TOKEN", "SR_YT_OAUTH_CLIENT_ID", "SR_YT_OAUTH_CLIENT_SECRET")


# ------------------------------------------------------------- очередь (read-only) --

def load_queue_lib():
    """Одобренные тексты берём только из очереди — импортируем approve-queue.py."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "approve-queue.py")
    spec = importlib.util.spec_from_file_location("approve_queue", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ------------------------------------------------------------------- окружение --

def sanitize(text, *secrets):
    for s in secrets:
        if s and s in text:
            text = text.replace(s, "***")
    return text


def emit(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def get_key(lib, name):
    return lib.get_setting(name)


# ------------------------------------------------------------------- запросы --

def refresh_access_token(lib):
    """Обмен refresh-токена на access-токен. Возвращает (token, None) или (None, hint)."""
    refresh = get_key(lib, "SR_YT_OAUTH_TOKEN")
    client_id = get_key(lib, "SR_YT_OAUTH_CLIENT_ID")
    client_secret = get_key(lib, "SR_YT_OAUTH_CLIENT_SECRET")
    body = urllib.parse.urlencode({
        "grant_type": "refresh_token",
        "refresh_token": refresh,
        "client_id": client_id,
        "client_secret": client_secret,
    }).encode("utf-8")
    req = urllib.request.Request(TOKEN_URL, data=body, method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded",
                                          "User-Agent": "sr-reputation-poster/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", "replace")[:200]
        except Exception:
            pass
        return None, ("Google не выдал access-токен (HTTP %s). %s Похоже, refresh-токен "
                      "устарел или отозван — перевыпусти его по сценарию подключения "
                      "YouTube и запиши в env заново." % (exc.code, sanitize(detail, refresh,
                                                                       client_secret)))
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
        return None, ("Нет связи с Google (%s). Проверь интернет и попробуй ещё раз; "
                      "если не проходит — ответ можно отправить вручную." % sanitize(str(exc), refresh))
    token = data.get("access_token")
    if not token:
        return None, ("Google ответил без access-токена. Проверь настройки OAuth-клиента "
                      "(SR_YT_OAUTH_CLIENT_ID / SECRET) по сценарию подключения YouTube.")
    return token, None


def insert_reply(token, parent_comment_id, text):
    """comments.insert: ответ (reply) на комментарий parent_comment_id."""
    url = API_BASE + "/comments?" + urllib.parse.urlencode({"part": "snippet"})
    body = json.dumps({"snippet": {"parentId": parent_comment_id,
                                   "textOriginal": text}}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/json",
                                          "Authorization": "Bearer %s" % token,
                                          "User-Agent": "sr-reputation-poster/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


# --------------------------------------------------------------------- main --

def parse_flags(args):
    flags = {"mock": False, "next_from_queue": False, "draft_id": None, "sleep_after": 0}
    rest = list(args)
    while rest:
        arg = rest.pop(0)
        if arg == "--mock":
            flags["mock"] = True
        elif arg == "--next-from-queue":
            flags["next_from_queue"] = True
        elif arg == "--draft-id":
            if not rest:
                emit({"error": "флагу --draft-id нужно значение",
                      "human_hint": "Пример: post-youtube.py --draft-id d1 --mock."})
                sys.exit(2)
            flags["draft_id"] = rest.pop(0)
        elif arg == "--sleep-after":
            if not rest:
                emit({"error": "флагу --sleep-after нужно число секунд",
                      "human_hint": "Пример: --sleep-after 45."})
                sys.exit(2)
            try:
                flags["sleep_after"] = int(rest.pop(0))
            except ValueError:
                emit({"error": "флагу --sleep-after нужно число секунд",
                      "human_hint": "Пример: --sleep-after 45."})
                sys.exit(2)
        else:
            emit({"error": "неизвестный флаг: %s" % arg,
                  "human_hint": "Допустимые флаги: --next-from-queue, --draft-id ID, "
                                "--mock, --sleep-after N."})
            sys.exit(2)
    if not flags["next_from_queue"] and not flags["draft_id"]:
        emit({"error": "не задан источник элемента очереди",
              "human_hint": "Запусти с --next-from-queue (обычный режим) или "
                            "--draft-id ID (конкретный черновик)."})
        sys.exit(2)
    return flags


def take_item(lib, flags):
    """Элемент очереди youtube (waiting) — по draft_id или next-one. None + статус, если нет."""
    if flags["draft_id"]:
        queue = lib.load_queue()
        item = lib.find_item(queue, flags["draft_id"])
        if item is None or item.get("platform") != "youtube":
            return None, {"status": "not_found",
                          "human_hint": "В очереди нет ютуб-черновика с id %s. "
                                        "Посмотри список: approve-queue.py list." % flags["draft_id"]}
        if item.get("status") != "waiting":
            if item.get("status") == "failed":
                hint = ("Этот черновик раньше не прошёл (status: failed). Верни его в "
                        "очередь и повтори: скажи «доклеить» — вернём командой "
                        "mark --draft-id %s --status waiting и запустим постер снова."
                        % flags["draft_id"])
            else:
                hint = ("Этот ответ уже обработан (статус: %s) — повторно "
                        "не отправляем, дублей нет." % item.get("status"))
            return None, {"status": item.get("status"),
                          "draft_id": flags["draft_id"],
                          "human_hint": hint}
        return item, None
    raw = None
    # next-one печатает либо элемент (есть draft_id), либо статус-обёртку.
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            lib.cmd_next_one(["--platform", "youtube"])
        except SystemExit:
            pass
    try:
        raw = json.loads(buf.getvalue())
    except ValueError:
        return None, {"status": "error",
                      "human_hint": "Очередь ответила не-JSON — сообщи Мише."}
    if "draft_id" not in raw:
        return None, raw
    return raw, None


def main():
    flags = parse_flags(sys.argv[1:])
    lib = load_queue_lib()

    item, status = take_item(lib, flags)
    if item is None:
        emit(status)
        sys.exit(0)

    if flags["mock"]:
        # Мок-прогон: сети и токена нет, очередь и статусы — настоящие.
        if flags["sleep_after"]:
            time.sleep(flags["sleep_after"])
        marked = parse_mark_output(mark_quiet(lib, item, "posted", mock=True,
                                              returned_id="mock-%s" % item["draft_id"],
                                              reason="мок: отправки в сеть не было"))
        out = {
            "status": "posted",
            "mock": True,
            "note": "[МОК/MOCK] отправки в сеть не было — обкатка очереди и статусов",
            "draft_id": item["draft_id"],
            "platform": "youtube",
            "comment_id": "mock-%s" % item["draft_id"],
            "already_posted": bool(marked.get("already_posted")),
            "screenshot": None,
        }
        warning = queue_mark_warning(marked, published=True)
        if warning:
            out["warning"] = warning
        emit(out)
        sys.exit(0)

    # --- живой путь: нужны все три OAuth-переменных -------------------------
    missing = [name for name in REQUIRED_ENV if not get_key(lib, name)]
    if missing:
        emit({
            "status": "not_configured",
            "missing": missing,
            "human_hint": ("Автоответы на YouTube не подключены: нет %s. Это нормально — "
                           "подключит Вера по сценарию подключения (Phase 6). До тех пор "
                           "ответы отправляются вручную." % ", ".join(missing)),
        })
        sys.exit(0)

    token, err = refresh_access_token(lib)
    if not token:
        marked = parse_mark_output(mark_quiet(lib, item, "failed", err))
        out = {"status": "failed", "draft_id": item["draft_id"],
               "error": "не удалось получить access-токен", "human_hint": err}
        warning = queue_mark_warning(marked, published=False)
        if warning:
            out["warning"] = warning
        emit(out)
        sys.exit(0)

    try:
        data = insert_reply(token, item["source_comment_id"], item["text"])
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            body = json.loads(exc.read().decode("utf-8"))
            detail = body.get("error", {}).get("message", "")[:200]
        except Exception:
            pass
        hint = ("YouTube не принял ответ (HTTP %s). %s Если комментарий удалён или ответ "
                "уже есть — пометь элемент skipped; если сбой временный — скажи «доклеить» "
                "(вернём в очередь: mark --draft-id %s --status waiting) и повтори; "
                "иначе ответы можно отправить вручную, а Мишу попросить проверить доступы."
                % (exc.code, detail, item["draft_id"]))
        marked = parse_mark_output(mark_quiet(lib, item, "failed", sanitize(hint, token)))
        out = {"status": "failed", "draft_id": item["draft_id"],
               "error": sanitize("YouTube API: HTTP %s %s" % (exc.code, detail), token),
               "human_hint": hint}
        warning = queue_mark_warning(marked, published=False)
        if warning:
            out["warning"] = warning
        emit(out)
        sys.exit(0)
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
        hint = ("Нет связи с YouTube (%s). Проверь интернет и повтори: скажи «доклеить» — "
                "вернём элемент в очередь (mark --draft-id %s --status waiting) и запустим "
                "постер снова; задвоения не будет."
                % (sanitize(str(exc), token), item["draft_id"]))
        marked = parse_mark_output(mark_quiet(lib, item, "failed", hint))
        out = {"status": "failed", "draft_id": item["draft_id"], "human_hint": hint}
        warning = queue_mark_warning(marked, published=False)
        if warning:
            out["warning"] = warning
        emit(out)
        sys.exit(0)

    comment_id = data.get("id")
    marked = parse_mark_output(mark_quiet(lib, item, "posted", returned_id=comment_id))
    if flags["sleep_after"]:
        time.sleep(flags["sleep_after"])
    out = {
        "status": "posted",
        "draft_id": item["draft_id"],
        "platform": "youtube",
        "comment_id": comment_id,
        "screenshot": None,
        "human_hint": "Ответ опубликован на YouTube (официальным API, как ответ на комментарий).",
    }
    warning = queue_mark_warning(marked, published=True)
    if warning:
        out["warning"] = warning
    emit(out)
    sys.exit(0)


def mark_quiet(lib, item, status, reason=None, returned_id=None, mock=False):
    """Отметка в очереди без вывода (stdout остаётся одним JSON-документом)."""
    args = ["--draft-id", item["draft_id"], "--status", status]
    if mock:
        args.append("--mock")
    if reason:
        args += ["--reason", reason]
    if returned_id:
        args += ["--returned-id", returned_id]
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            lib.cmd_mark(args)
        except SystemExit:
            pass
        except Exception as exc:  # очередь не смогла записать файл (нет прав, диск)
            return json.dumps({"error": "очередь не записала статус: %r" % exc,
                               "human_hint": "сообщи Мише"}, ensure_ascii=False)
    return buf.getvalue()


def parse_mark_output(raw):
    """Разобрать вывод cmd_mark (MA-04); {} — если очередь ответила не-JSON
    (например, не смогла записать файл очереди)."""
    try:
        parsed = json.loads(raw)
    except ValueError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def queue_mark_warning(marked, published):
    """MA-04: mark_quiet мог не сработать — тогда НЕ молчать в итоговом JSON,
    иначе оркестратор видит posted при несохранённом статусе и элемент уйдёт
    повторно на следующем прогоне."""
    if not marked.get("error"):
        return None
    if published:
        return ("ответ опубликован, но статус в очереди сохранить не удалось — сообщи "
                "Мише, чтобы элемент не ушёл повторно на следующем прогоне")
    return ("ответ НЕ отправлен, и пометить элемент в очереди не удалось "
            "(он остался waiting) — на следующем прогоне будет повторная попытка; "
            "сообщи Мише")


if __name__ == "__main__":
    main()
