#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
monitor-youtube.py — мониторинг новых комментариев на YouTube-канале школы
SwimRocket (для шага 0 режима «утро» скилла /sr-reputation).

Только стандартная библиотека Python 3 — ноль pip-зависимостей.

Ключи — только из окружения, никогда не в коде:
  SR_YT_API_KEY — ключ YouTube Data API v3.
Переменную можно передать в процессе ИЛИ записать в env-файл состояния:
  $SR_STATE_ROOT/env, по умолчанию ~/.sr-harness/sr-reputation/env (формат KEY=VALUE).

Что делает:
  1. channels.list (part=contentDetails, forHandle=swim_rocket) -> плейлист uploads.
  2. playlistItems — последние ~15 видео канала.
  3. commentThreads (part=snippet, order=time, maxResults=50) по каждому видео.
  4. Фильтр новых комментариев через seen.json (дедупликация по id комментария).
  5. Печатает JSON-массив найденного; добавляет новые id в seen.json
     (кроме режима --dry-run).

Вывод в stdout — всегда РОВНО ОДИН JSON-документ:
  успех             -> [{source, video_title, video_url, author, text,
                        comment_id, published_at}, ...]  (пустой массив = нет нового)
  нет ключа         -> {"status": "not_configured", "human_hint": "..."}
  ошибка квот/сети  -> {"error": "...", "human_hint": "..."}

Код выхода — 0 во всех рабочих случаях (not_configured и ошибка — не падение:
«утро» должно продолжаться в ручном режиме). Отличный от 0 — только при
неправильном вызове (неизвестный флаг).

Флаги:
  --dry-run   показать, что нашлось, но НЕ обновлять seen.json.
"""

import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import html as html_mod

API_BASE = "https://www.googleapis.com/youtube/v3"
CHANNEL_HANDLE = "swim_rocket"
MAX_VIDEOS = 15
# Окно 50 свежих комментариев на видео — осознанный дизайн (IN-05, пагинация сознательно
# не делается): для текущего канала хватает; комментарии глубже окна в отчёт не попадают.
MAX_COMMENTS_PER_VIDEO = 50
SEEN_KEEP = 5000  # храним не больше последних N id, чтобы файл не рос бесконечно


# ---------------------------------------------------------------- окружение --

def state_root():
    return os.environ.get("SR_STATE_ROOT") or os.path.join(
        os.path.expanduser("~"), ".sr-harness", "sr-reputation")


def env_file_path():
    return os.path.join(state_root(), "env")


def load_env_file():
    """Читает env-файл KEY=VALUE. Никогда не печатает значения."""
    vals = {}
    try:
        with open(env_file_path(), "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key:
                    vals[key] = val
    except OSError:
        pass
    return vals


def get_key(name):
    val = os.environ.get(name)
    if val:
        return val.strip()
    return (load_env_file().get(name) or "").strip()


def seen_path():
    return os.path.join(state_root(), "state", "seen.json")


def load_seen():
    try:
        with open(seen_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {}


def save_seen(seen):
    # Атомарная запись (WR-03): обрыв посреди записи не оставит битый JSON —
    # иначе следующий прогон молча потеряет весь дедуп и переотчитает всё накопленное.
    path = seen_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(seen, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


# ------------------------------------------------------------------- вывод --

def sanitize(text, secret):
    """Не даём значению ключа попасть в сообщение об ошибке."""
    if secret and secret in text:
        text = text.replace(secret, "***")
    return text


def emit(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def not_configured():
    emit({
        "status": "not_configured",
        "human_hint": ("Мониторинг YouTube не настроен: нет ключа SR_YT_API_KEY "
                       "(его один раз записывает Миша в ~/.sr-harness/sr-reputation/env). "
                       "Работаем как раньше — данные принесёт человек."),
    })
    sys.exit(0)


def fail(error, human_hint, secret=None):
    emit({"error": sanitize(error, secret), "human_hint": human_hint})
    sys.exit(0)


def api_error_hint(status_or_reason):
    if status_or_reason in ("quotaExceeded", "dailyLimitExceeded", "rateLimitExceeded") or \
       "quota" in str(status_or_reason).lower():
        return ("Лимит запросов к YouTube на сегодня исчерпан — это не поломка. "
                "Продолжай без мониторинга; завтра лимит обновится. Напомни Мише, "
                "если повторится несколько дней подряд.")
    if status_or_reason in ("keyInvalid", "API_KEY_INVALID", "forbidden") or \
       "key" in str(status_or_reason).lower():
        return ("Ключ YouTube не принят сервером. Напомни Мише: похоже, ключ "
                "скопировался не до конца или YouTube Data API не включён.")
    return ("Не получилось связаться с YouTube. Проверь интернет и попробуй ещё раз; "
            "если не проходит — работаем как раньше и напомни Мише.")


# ------------------------------------------------------------------- запросы --

def http_get(path, params, secret):
    url = API_BASE + path + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "sr-reputation-monitor/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def get_uploads_playlist_id(key):
    """Идентификатор канала по хэндлу @swim_rocket -> id плейлиста uploads."""
    items = []
    for param in ({"part": "contentDetails", "forHandle": CHANNEL_HANDLE},
                  {"part": "contentDetails", "forUsername": CHANNEL_HANDLE}):
        data = http_get("/channels", dict(param, key=key), key)
        items = data.get("items") or []
        if items:
            break
    if not items:
        fail("канал @%s не найден через YouTube API" % CHANNEL_HANDLE,
             "Канал школы не найден по хэндлу. Напомни Мише проверить имя канала "
             "(youtube.com/@%s)." % CHANNEL_HANDLE, key)
    uploads = (items[0].get("contentDetails", {}).get("relatedPlaylists", {}) or {}).get("uploads")
    if not uploads:
        fail("у канала нет плейлиста uploads",
             "У канала школы нет публичных видео или плейлист скрыт. Напомни Мише.", key)
    return uploads


def fetch_videos(uploads_id, key):
    data = http_get("/playlistItems",
                    {"part": "snippet", "playlistId": uploads_id,
                     "maxResults": MAX_VIDEOS, "key": key}, key)
    videos = []
    for item in data.get("items", []):
        snippet = item.get("snippet", {})
        video_id = (snippet.get("resourceId") or {}).get("videoId")
        if video_id:
            videos.append((video_id, snippet.get("title", "")))
    return videos


def strip_html(text):
    text = re.sub(r"<[^>]+>", " ", text or "")
    text = html_mod.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


def fetch_new_comments(video_id, video_title, seen_ids, key):
    data = http_get("/commentThreads",
                    {"part": "snippet", "videoId": video_id,
                     "order": "time", "maxResults": MAX_COMMENTS_PER_VIDEO,
                     "key": key}, key)
    found = []
    for item in data.get("items", []):
        top = item.get("snippet", {}).get("topLevelComment") or {}
        snippet = top.get("snippet", {})
        comment_id = top.get("id")
        if not comment_id or comment_id in seen_ids:
            continue
        text = snippet.get("textOriginal") or strip_html(snippet.get("textDisplay", ""))
        found.append({
            "source": "youtube",
            "video_title": video_title,
            "video_url": "https://www.youtube.com/watch?v=%s&lc=%s" % (video_id, comment_id),
            "author": snippet.get("authorDisplayName", ""),
            "text": text,
            "comment_id": comment_id,
            "published_at": snippet.get("publishedAt", ""),
        })
    return found


# --------------------------------------------------------------------- main --

def usage_error(msg, hint):
    """Неправильный вызов — код 2 (как обещает docstring), JSON в stdout."""
    emit({"error": msg, "human_hint": hint})
    sys.exit(2)


def main():
    # Валидация флагов безусловная (IN-01): посторонний флаг — ошибка вызова,
    # даже если ключ мониторинга ещё не настроен.
    unknown = [a for a in sys.argv[1:] if a != "--dry-run"]
    if unknown:
        usage_error("неизвестный флаг: %s" % unknown[0],
                    "Запусти скрипт без флагов или только с --dry-run.")

    key = get_key("SR_YT_API_KEY")
    if not key:
        not_configured()

    dry_run = "--dry-run" in sys.argv[1:]

    try:
        uploads_id = get_uploads_playlist_id(key)
        videos = fetch_videos(uploads_id, key)
    except urllib.error.HTTPError as exc:
        reason = ""
        try:
            body = json.loads(exc.read().decode("utf-8"))
            reasons = body.get("error", {}).get("errors", []) or [{}]
            reason = reasons[0].get("reason", "")
        except Exception:
            pass
        fail("YouTube API: HTTP %s %s" % (exc.code, reason),
             api_error_hint(reason or str(exc.code)), key)
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
        fail("нет связи с YouTube API: %s" % sanitize(str(exc), key),
             api_error_hint("network"), key)

    seen = load_seen()
    seen_ids = set(seen.get("youtube", []))
    results = []

    for video_id, video_title in videos:
        try:
            found = fetch_new_comments(video_id, video_title, seen_ids, key)
        except urllib.error.HTTPError as exc:
            reason = ""
            try:
                body = json.loads(exc.read().decode("utf-8"))
                reasons = body.get("error", {}).get("errors", []) or [{}]
                reason = reasons[0].get("reason", "")
            except Exception:
                pass
            fail("YouTube API: HTTP %s %s (видео %s)" % (exc.code, reason, video_id),
                 api_error_hint(reason or str(exc.code)), key)
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
            fail("нет связи с YouTube API: %s" % sanitize(str(exc), key),
                 api_error_hint("network"), key)
        for item in found:
            results.append(item)
            seen_ids.add(item["comment_id"])
        if found and not dry_run:
            # Инкрементальное сохранение (WR-03): сбой на k-м видео из 15 не теряет
            # найденное по предыдущим — seen пишется сразу после каждого видео.
            seen["youtube"] = (seen.get("youtube", [])
                               + [i["comment_id"] for i in found])[-SEEN_KEEP:]
            save_seen(seen)

    emit(results)
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:  # контракт «ровно один JSON» даже при неожиданном сбое
        fail("неожиданная ошибка: %r" % exc,
             "Что-то сломалось в самом скрипте мониторинга YouTube — сообщи Мише и "
             "пришли ему этот ответ целиком.",
             get_key("SR_YT_API_KEY"))
