#!/usr/bin/env bash
#
# sr-sync.sh — самообновление скилла sr-reputation: скачивает свежий архив бандла
# по ссылке и заменяет ТОЛЬКО папки скилла в ~/.zcode/skills/sr-reputation и
# ~/.claude/skills/sr-reputation.
#
# Что НЕ трогает никогда: env-файл и журнал ~/.sr-harness (настройки, доступы,
# прогоны, черновики остаются как были), других ассистентов не касается.
#
# Запускай двойным кликом update.command рядом с этим файлом — руками запускать
# не нужно. Только библиотеки macOS (curl, unzip), ничего не устанавливает.
#
# Использование:
#   bash sr-sync.sh            # обновить (если есть что)
#   bash sr-sync.sh --check    # только сравнить версии, ничего не менять
#
# Ссылка на архив:
#   env SR_SYNC_URL (полная ссылка на zip) перекрывает всё;
#   иначе — вшитая константа SR_HARNESS_REPO_URL + имя архива скилла.
#   Репо публичный, без секретов; токены не нужны и не используются.

set -u

SKILL_NAME="sr-reputation"
SKILL_TITLE="«Репутация»"
BUNDLE_ZIP="sr-harness.zip"

# Плейсхолдер: финальный URL публичного репо впишет Миша после создания репо.
SR_HARNESS_REPO_URL="https://github.com/Swimrocket-Team/harness"

SYNC_URL="${SR_SYNC_URL:-${SR_HARNESS_REPO_URL}/raw/main/${BUNDLE_ZIP}}"

ZCODE_SKILL_DIR="$HOME/.zcode/skills/$SKILL_NAME"
CLAUDE_SKILL_DIR="$HOME/.claude/skills/$SKILL_NAME"

# Честный статус без ошибки: обновить не вышло — работает старая версия.
# Никогда не падает с ненулевым кодом: обновление — необязательная операция.
graceful_fail() {
  echo ""
  echo "Обновить не удалось — работает старая версия, ничего не сломалось."
  echo "Причина: $1"
  echo "Проверь интернет и попробуй ещё раз позже; если не проходит — напиши Мише."
  exit 0
}

read_version() {  # $1 = путь к папке скилла; печатает версию или пусто
  [ -f "$1/VERSION" ] && tr -d ' \t\n\r' < "$1/VERSION"
}

check_mode=0
[ "${1:-}" = "--check" ] || [ "${1:-}" = "" ] || {
  echo "Неизвестный флаг: $1 (доступны: без флагов, --check)" >&2
  exit 2
}
[ "${1:-}" = "--check" ] && check_mode=1

# --- скачивание во временную папку --------------------------------------------
WORK="$(mktemp -d "${TMPDIR:-/tmp}/sr-sync.XXXXXX")" || graceful_fail "не удалось создать временную папку"
trap 'rm -rf "$WORK"' EXIT

echo "Ассистент $SKILL_TITLE: проверяю обновление…"
echo "  скачиваю свежую версию…"
curl -fL --silent --show-error --max-time 120 -o "$WORK/bundle.zip" "$SYNC_URL" \
  || graceful_fail "архив не скачался (нет интернета или ссылка недоступна)"

unzip -q -o "$WORK/bundle.zip" -d "$WORK/unpacked" \
  || graceful_fail "архив скачался, но не распаковался"

# --- что установлено сейчас ---------------------------------------------------
INSTALLED_DIR=""
[ -d "$ZCODE_SKILL_DIR" ] && INSTALLED_DIR="$ZCODE_SKILL_DIR"
[ -z "$INSTALLED_DIR" ] && [ -d "$CLAUDE_SKILL_DIR" ] && INSTALLED_DIR="$CLAUDE_SKILL_DIR"

CURRENT_VERSION=""
[ -n "$INSTALLED_DIR" ] && CURRENT_VERSION="$(read_version "$INSTALLED_DIR")"

echo "  установленная версия: ${CURRENT_VERSION:-неизвестно}"

if [ -z "$INSTALLED_DIR" ]; then
  echo ""
  echo "Ассистент $SKILL_TITLE ещё не установлен на этом компьютере — обновлять нечего."
  echo "Сначала установи его: дважды кликни install.command из папки архива."
  exit 0
fi

# В архиве бандл может лежать в корне или в одной папке — ищем скилл в обоих случаях.
NEW_SKILL_DIR=""
for cand in "$WORK/unpacked/skills/$SKILL_NAME" "$WORK/unpacked"/*/skills/"$SKILL_NAME"; do
  [ -f "$cand/SKILL.md" ] && NEW_SKILL_DIR="$cand" && break
done
[ -n "$NEW_SKILL_DIR" ] || graceful_fail "в архиве нет ассистента $SKILL_TITLE (не тот файл?)"

NEW_VERSION="$(read_version "$NEW_SKILL_DIR")"

if [ -n "$CURRENT_VERSION" ] && [ "$CURRENT_VERSION" = "$NEW_VERSION" ]; then
  echo ""
  echo "У тебя уже последняя версия (${CURRENT_VERSION:-без версии}). Обновление не нужно."
  exit 0
fi

if [ "$check_mode" = "1" ]; then
  echo ""
  echo "Доступно обновление: ${NEW_VERSION:-без версии} (у тебя: ${CURRENT_VERSION:-без версии})."
  echo "Чтобы обновить — снова дважды кликни update.command."
  exit 0
fi

# --- замена ТОЛЬКО папок скилла (env-файл и ~/.sr-harness не трогаем) ---------
for dest in "$ZCODE_SKILL_DIR" "$CLAUDE_SKILL_DIR"; do
  [ -d "$dest" ] || continue
  rm -rf "$dest"
  cp -R "$NEW_SKILL_DIR" "$dest"
  rm -rf "$dest/state"   # журнал — только в STATE_ROOT, не в скилле
  find "$dest" -type f \( -name '*.sh' -o -name '*.command' \) -exec chmod +x {} +
done

echo ""
echo "Готово: обновлено до версии ${NEW_VERSION:-без версии}."
echo "Твои настройки, журнал и черновики не тронуты."
exit 0
