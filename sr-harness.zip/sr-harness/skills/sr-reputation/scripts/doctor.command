#!/usr/bin/env bash
#
# doctor.command — проверка ассистента «Репутация» двойным кликом (macOS).
# Запускает doctor.sh из этой же папки и держит окно открытым до Enter.

set -u

DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"

bash "$DIR/doctor.sh"

echo ""
read -r -p "Нажми Enter, чтобы закрыть это окно" _
