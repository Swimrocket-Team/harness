#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
post-browser.py — постер одобренного ответа на площадках без API
(Яндекс.Бизнес / 2ГИС / Zoon) через браузер (Playwright) с сохранённой сессией.

Берёт ОДИН элемент очереди (approve-queue.py next-one) и вставляет ответ в форму
«Ответить» под исходным отзывом. Текст берётся ТОЛЬКО из элемента очереди — в момент
постинга ничего не сочиняется (ноль LLM-вызовов). После отправки пишется скрин-
подтверждение в state/out/; капча или ненайденный элемент → failed + скрин + подсказка.

Сессии кабинетов — только на машине Веры, вне git:
  $SR_STATE_ROOT/sessions/<platform>.json   (storage_state Playwright; подключит Вера)

Playwright на машине ставится ОДИН РАЗ (это делает человек, не скрипт):
  python3 -m pip install playwright
  python3 -m playwright install chromium
Скрипт сам играть в установку не берётся: нет playwright → setup_required + инструкция.

Вывод в stdout — РОВНО ОДИН JSON-документ; код выхода 0 во всех рабочих случаях
(setup_required / not_configured / пусто / стоп-кран / лимит / сбой площадки — не
падение). Код 2 — только неправильный вызов.

Флаги:
  --platform P     площадка: yandex | 2gis | zoon (с --next-from-queue или --draft-id)
  --next-from-queue взять следующий waiting-элемент этой площадки из очереди
  --draft-id ID    взять из очереди конкретный элемент
  --mock           мок-прогон: без браузера и сессий; posted c пометкой mock
  --sleep-after N  подождать N секунд после отправки (в скилле паузу держит оркестратор)
"""

import contextlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import time
from datetime import datetime

BROWSER_PLATFORMS = ("yandex", "2gis", "zoon")

# URL страниц отзывов и селекторы — УТОЧНИТЬ при первом живом запуске (Phase 6,
# вместе с подключением сессий Веры). Здесь только заготовки-константы.
PLATFORMS = {
    "yandex": {
        "name": "Яндекс.Бизнес",
        "reviews_url": "https://business.yandex.ru/reviews",  # УТОЧНИТЬ при первом живом запуске
        "selectors": {  # УТОЧНИТЬ при первом живом запуске
            "reply_button": "text=Ответить",
            "reply_field": "textarea",
            "submit_button": "text=Отправить",
        },
    },
    "2gis": {
        "name": "2ГИС",
        "reviews_url": "https://partners.2gis.ru/reviews",  # УТОЧНИТЬ при первом живом запуске
        "selectors": {  # УТОЧНИТЬ при первом живом запуске
            "reply_button": "text=Ответить",
            "reply_field": "textarea",
            "submit_button": "text=Отправить",
        },
    },
    "zoon": {
        "name": "Zoon",
        "reviews_url": "https://zoon.ru/partner/reviews",  # УТОЧНИТЬ при первом живом запуске
        "selectors": {  # УТОЧНИТЬ при первом живом запуске
            "reply_button": "text=Ответить",
            "reply_field": "textarea",
            "submit_button": "text=Отправить",
        },
    },
}

INSTALL_HINT = ("Чтобы отвечать на %s самому, нужно один раз установить программу-браузер. "
                "Открой приложение «Терминал» и выполни две команды (по очереди):\n"
                "  python3 -m pip install playwright\n"
                "  python3 -m playwright install chromium\n"
                "Если что-то не получится — напиши Мише.")


# ------------------------------------------------------------------- очередь --

def load_queue_lib():
    """Одобренные тексты берём только из очереди — импортируем approve-queue.py."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "approve-queue.py")
    spec = importlib.util.spec_from_file_location("approve_queue", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def emit(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def mark_quiet(lib, item, status, reason=None, returned_id=None, mock=False):
    """Отметка в очереди без вывода (stdout остаётся одним JSON-документом)."""
    args = ["--draft-id", item["draft_id"], "--status", status]
    if mock:
        args.append("--mock")
    if reason:
        args += ["--reason", reason]
    if returned_id:
        args += ["--returned-id", returned_id]
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            lib.cmd_mark(args)
        except SystemExit:
            pass
        except Exception as exc:  # очередь не смогла записать файл (нет прав, диск)
            return json.dumps({"error": "очередь не записала статус: %r" % exc,
                               "human_hint": "сообщи Мише"}, ensure_ascii=False)
    return buf.getvalue()


def parse_mark_output(raw):
    """Разобрать вывод cmd_mark (MA-04); {} — если очередь ответила не-JSON
    (например, не смогла записать файл очереди)."""
    try:
        parsed = json.loads(raw)
    except ValueError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def queue_mark_warning(marked, published):
    """MA-04: mark_quiet мог не сработать — тогда НЕ молчать в итоговом JSON,
    иначе оркестратор видит posted при несохранённом статусе и элемент уйдёт
    повторно на следующем прогоне."""
    if not marked.get("error"):
        return None
    if published:
        return ("ответ опубликован, но статус в очереди сохранить не удалось — сообщи "
                "Мише, чтобы элемент не ушёл повторно на следующем прогоне")
    return ("ответ НЕ отправлен, и пометить элемент в очереди не удалось "
            "(он остался waiting) — на следующем прогоне будет повторная попытка; "
            "сообщи Мише")


# -------------------------------------------------------------------- флаги --

def parse_flags(args):
    flags = {"platform": None, "next_from_queue": False, "draft_id": None,
             "mock": False, "sleep_after": 0}
    rest = list(args)
    while rest:
        arg = rest.pop(0)
        if arg == "--mock":
            flags["mock"] = True
        elif arg == "--next-from-queue":
            flags["next_from_queue"] = True
        elif arg == "--platform":
            if not rest:
                emit({"error": "флагу --platform нужно значение",
                      "human_hint": "Площадка — одна из: %s." % ", ".join(BROWSER_PLATFORMS)})
                sys.exit(2)
            flags["platform"] = rest.pop(0)
        elif arg == "--draft-id":
            if not rest:
                emit({"error": "флагу --draft-id нужно значение",
                      "human_hint": "Пример: post-browser.py --platform 2gis --draft-id d3 --mock."})
                sys.exit(2)
            flags["draft_id"] = rest.pop(0)
        elif arg == "--sleep-after":
            if not rest:
                emit({"error": "флагу --sleep-after нужно число секунд",
                      "human_hint": "Пример: --sleep-after 45."})
                sys.exit(2)
            try:
                flags["sleep_after"] = int(rest.pop(0))
            except ValueError:
                emit({"error": "флагу --sleep-after нужно число секунд",
                      "human_hint": "Пример: --sleep-after 45."})
                sys.exit(2)
        else:
            emit({"error": "неизвестный флаг: %s" % arg,
                  "human_hint": "Допустимые флаги: --platform P, --next-from-queue, "
                                "--draft-id ID, --mock, --sleep-after N."})
            sys.exit(2)
    if not flags["next_from_queue"] and not flags["draft_id"]:
        emit({"error": "не задан источник элемента очереди",
              "human_hint": "Запусти с --next-from-queue и --platform (обычный режим) "
                            "или --draft-id ID."})
        sys.exit(2)
    if flags["draft_id"] is None and (flags["platform"] not in BROWSER_PLATFORMS):
        emit({"error": "нужна площадка: yandex, 2gis или zoon",
              "human_hint": "Пример: post-browser.py --platform yandex --next-from-queue."})
        sys.exit(2)
    return flags


def take_item(lib, flags):
    """Элемент очереди (browser-площадка, waiting) — по draft_id или next-one."""
    if flags["draft_id"]:
        queue = lib.load_queue()
        item = lib.find_item(queue, flags["draft_id"])
        if item is None or item.get("platform") not in BROWSER_PLATFORMS:
            return None, {"status": "not_found",
                          "human_hint": "В очереди нет черновика для %s с id %s. "
                                        "Посмотри список: approve-queue.py list."
                                        % ("/".join(BROWSER_PLATFORMS), flags["draft_id"])}
        if item.get("status") != "waiting":
            if item.get("status") == "failed":
                hint = ("Этот черновик раньше не прошёл (status: failed). Верни его в "
                        "очередь и повтори: скажи «доклеить» — вернём командой "
                        "mark --draft-id %s --status waiting и запустим постер снова."
                        % flags["draft_id"])
            else:
                hint = ("Этот ответ уже обработан (статус: %s) — повторно "
                        "не отправляем, дублей нет." % item.get("status"))
            return None, {"status": item.get("status"), "draft_id": flags["draft_id"],
                          "human_hint": hint}
        return item, None
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            lib.cmd_next_one(["--platform", flags["platform"]])
        except SystemExit:
            pass
    try:
        raw = json.loads(buf.getvalue())
    except ValueError:
        return None, {"status": "error",
                      "human_hint": "Очередь ответила не-JSON — сообщи Мише."}
    if "draft_id" not in raw:
        return None, raw
    return raw, None


# --------------------------------------------------------------- playwright --

def playwright_installed():
    """Мягкая проверка: playwright доступен этому же python3?"""
    try:
        proc = subprocess.run([sys.executable, "-c", "import playwright"],
                              capture_output=True, timeout=60)
        return proc.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def screenshot_path(lib):
    out_dir = os.path.join(lib.state_root(), "state", "out")
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    return os.path.join(out_dir, "post-%s.png" % stamp)


def post_via_browser(lib, platform, item, session_path):
    """Живой путь: открыть страницу отзывов, найти отзыв по якорю, ответить.
    Возвращает (ok, detail, screenshot)."""
    from playwright.sync_api import sync_playwright

    cfg = PLATFORMS[platform]
    shot = screenshot_path(lib)
    anchor = (item.get("anchor") or "").strip()
    if not anchor:
        # Скриншот здесь НЕ делался — отдаём None, а не вычисленный путь (IN-07);
        # кортеж из трёх значений, как ждёт вызывающий (ok, detail, shot).
        return False, ("В элементе очереди нет якоря исходного отзыва (текста, по которому "
                       "его найти на странице). Добавь ответ в очередь заново с --anchor."), None
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=False)
        context = browser.new_context(storage_state=session_path, locale="ru-RU")
        page = context.new_page()
        try:
            page.goto(cfg["reviews_url"], wait_until="domcontentloaded", timeout=45000)
            page.wait_for_timeout(3000)  # кабинеты дорисовываются скриптами
            if page.locator("text=/капч/i").count() or page.locator("text=/captcha/i").count():
                page.screenshot(path=shot, full_page=True)
                return False, ("Площадка показала капчу — робот останавливается. Войди в "
                               "кабинет вручную, обнови сессию по сценарию подключения.", shot)
            review = page.get_by_text(anchor[:40], exact=False).first
            review.wait_for(state="visible", timeout=20000)
            card = review.locator("xpath=ancestor-or-self::div[contains(@class,'review')][1]")
            sel = cfg["selectors"]
            card.locator(sel["reply_button"]).first.click()
            page.wait_for_timeout(1500)
            # Поле и кнопку ищем ВНУТРИ карточки отзыва (WR-05): глобальный поиск
            # по странице может попасть в чужую форму — текст ушёл бы не туда.
            card.locator(sel["reply_field"]).first.fill(item["text"])
            card.locator(sel["submit_button"]).first.click()
            page.wait_for_timeout(3000)
            # Публикация подтверждается появлением текста ответа на странице (WR-05):
            # клик мимо формы или тихий отказ площадки больше не считается успехом.
            reply_confirmed = page.get_by_text(item["text"][:40], exact=False).count() > 0
            page.screenshot(path=shot, full_page=True)
            if not reply_confirmed:
                return False, ("Клик «Отправить» прошёл, но текст ответа на странице не "
                               "появился — публикация не подтвердилась. Проверь вручную "
                               "(элемент очереди НЕ помечен отправленным): повтори отправку "
                               "или ответь руками.", shot)
            return True, "Ответ отправлен (скрин-подтверждение записан).", shot
        except Exception as exc:  # таймаут, кнопка не нашлась, сессия протухла
            try:
                page.screenshot(path=shot, full_page=True)
            except Exception:
                pass
            return False, ("Не получилось отправить ответ на %s: %s Скорее всего, сессия "
                           "кабинета устарела или страница изменилась. Обнови сессию по "
                           "сценарию подключения или ответь вручную."
                           % (cfg["name"], str(exc)[:200])), shot
        finally:
            context.close()
            browser.close()


# --------------------------------------------------------------------- main --

def main():
    flags = parse_flags(sys.argv[1:])
    lib = load_queue_lib()

    platform = flags["platform"]
    item, status = take_item(lib, flags)
    if item is None:
        emit(status)
        sys.exit(0)
    platform = item["platform"]
    cfg = PLATFORMS[platform]

    if flags["mock"]:
        shot = screenshot_path(lib)
        if flags["sleep_after"]:
            time.sleep(flags["sleep_after"])
        marked = parse_mark_output(mark_quiet(lib, item, "posted", mock=True,
                                              returned_id="mock-%s" % item["draft_id"],
                                              reason="мок: отправки в сеть не было"))
        out = {
            "status": "posted",
            "mock": True,
            "note": "[МОК/MOCK] отправки в сеть не было — обкатка очереди и статусов",
            "draft_id": item["draft_id"],
            "platform": platform,
            "screenshot": shot + " (имитация: файл не создавался)",
        }
        warning = queue_mark_warning(marked, published=True)
        if warning:
            out["warning"] = warning
        emit(out)
        sys.exit(0)

    # --- 1. Playwright установлен? (нет — простая инструкция, не падение) ----
    if not playwright_installed():
        emit({
            "status": "setup_required",
            "missing": "playwright",
            "human_hint": INSTALL_HINT % cfg["name"],
        })
        sys.exit(0)

    # --- 2. Сессия кабинета подключена? --------------------------------------
    session_path = os.path.join(lib.state_root(), "sessions", "%s.json" % platform)
    if not os.path.exists(session_path):
        emit({
            "status": "not_configured",
            "missing": session_path,
            "human_hint": ("Сессия кабинета %s не подключена. Это нормально — подключит "
                           "Вера по сценарию подключения. До тех пор ответ отправляется "
                           "вручную: вот текст — %s" % (cfg["name"], item["text"])),
        })
        sys.exit(0)

    # --- 3. Живой путь --------------------------------------------------------
    ok, detail, shot = post_via_browser(lib, platform, item, session_path)
    if shot and not os.path.exists(shot):
        shot = None  # IN-07: не называем путь, которого нет (снимок не удался)
    if flags["sleep_after"]:
        time.sleep(flags["sleep_after"])
    if ok:
        marked = parse_mark_output(mark_quiet(lib, item, "posted", reason="через браузер"))
        out = {"status": "posted", "draft_id": item["draft_id"], "platform": platform,
               "screenshot": shot, "human_hint": detail}
        warning = queue_mark_warning(marked, published=True)
        if warning:
            out["warning"] = warning
        emit(out)
    else:
        marked = parse_mark_output(mark_quiet(lib, item, "failed", reason=detail))
        out = {"status": "failed", "draft_id": item["draft_id"], "platform": platform,
               "screenshot": shot, "human_hint": detail}
        warning = queue_mark_warning(marked, published=False)
        if warning:
            out["warning"] = warning
        emit(out)
    sys.exit(0)


if __name__ == "__main__":
    main()
