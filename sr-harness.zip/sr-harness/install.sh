#!/usr/bin/env bash
#
# managers/install.sh — установка менеджерского harness «Репутация» в хосты
# Z-Code и Claude Code (user-level: единственный документированно надёжный
# уровень для агентов в обоих хостах).
#
# Использование:
#   bash managers/install.sh              # установить (идемпотентно)
#   bash managers/install.sh --uninstall  # удалить скилл и агентов (state не трогает)
#
# Целевые точки (4):
#   ~/.zcode/skills/sr-reputation/   ~/.claude/skills/sr-reputation/
#   ~/.zcode/agents/sr-*.md          ~/.claude/agents/sr-*.md
#
# Журнал прогонов (STATE_ROOT) — вне целевых каталогов, один на оба хоста:
#   $SR_STATE_ROOT или ~/.sr-harness/sr-reputation

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_SRC="$SCRIPT_DIR/skills/sr-reputation"
AGENTS_SRC="$SCRIPT_DIR/agents"

ZCODE_SKILL_DIR="$HOME/.zcode/skills/sr-reputation"
CLAUDE_SKILL_DIR="$HOME/.claude/skills/sr-reputation"
ZCODE_AGENTS_DIR="$HOME/.zcode/agents"
CLAUDE_AGENTS_DIR="$HOME/.claude/agents"

STATE_ROOT="${SR_STATE_ROOT:-$HOME/.sr-harness/sr-reputation}"

fail() { echo "ERROR: $*" >&2; exit 1; }

[ -f "$SKILL_SRC/SKILL.md" ] || fail "нет $SKILL_SRC/SKILL.md — запускай из репо SwimRocket"
[ -f "$SKILL_SRC/algorithm.md" ] || fail "нет $SKILL_SRC/algorithm.md"

# --- uninstall ---------------------------------------------------------------
if [ "${1:-}" = "--uninstall" ]; then
  rm -rf "$ZCODE_SKILL_DIR" "$CLAUDE_SKILL_DIR"
  for host in "$ZCODE_AGENTS_DIR" "$CLAUDE_AGENTS_DIR"; do
    for f in "$AGENTS_SRC"/sr-*.md; do
      rm -f "$host/$(basename "$f")"
    done
  done
  echo "Удалено:"
  echo "  - $ZCODE_SKILL_DIR"
  echo "  - $CLAUDE_SKILL_DIR"
  echo "  - sr-*.md из $ZCODE_AGENTS_DIR и $CLAUDE_AGENTS_DIR"
  echo "STATE_ROOT не тронут (журналы и черновики остались): $STATE_ROOT"
  exit 0
fi

[ "${1:-}" = "" ] || fail "неизвестный флаг: $1 (доступен только --uninstall)"

# --- install: скилл в два хоста (без state/ — он живёт в STATE_ROOT) ---------
for dest in "$ZCODE_SKILL_DIR" "$CLAUDE_SKILL_DIR"; do
  mkdir -p "$(dirname "$dest")"
  rm -rf "$dest"
  cp -R "$SKILL_SRC" "$dest"
  rm -rf "$dest/state"   # журнал и черновики — только в STATE_ROOT, не в скилле
  rm -rf "$dest/scripts/__pycache__"   # мусор локальных импортов в хосты не тащим (IN-09)
  # Установка в один клик (05-05): права на запуск для двойного клика и doctor.
  # cp -R обычно сохраняет права, но после распаковки архива/копирования по сети
  # биты могли потеряться — выставляем явно.
  chmod +x "$dest/install.command" 2>/dev/null || true
  if [ -d "$dest/scripts" ]; then
    find "$dest/scripts" -type f \( -name '*.sh' -o -name '*.command' \) -exec chmod +x {} +
  fi
done

# --- install: агенты в два хоста ---------------------------------------------
shopt -s nullglob
agent_files=("$AGENTS_SRC"/sr-*.md)
[ "${#agent_files[@]}" -gt 0 ] || fail "в $AGENTS_SRC нет файлов sr-*.md"
for host in "$ZCODE_AGENTS_DIR" "$CLAUDE_AGENTS_DIR"; do
  mkdir -p "$host"
  for f in "${agent_files[@]}"; do
    cp "$f" "$host/"
  done
done
shopt -u nullglob

# --- STATE_ROOT: журнал и черновики ------------------------------------------
mkdir -p "$STATE_ROOT/state/runs" "$STATE_ROOT/state/out"

echo "Установлено (идемпотентно, повторный запуск безопасен):"
echo "  скилл  → $ZCODE_SKILL_DIR"
echo "  скилл  → $CLAUDE_SKILL_DIR"
for f in "${agent_files[@]}"; do
  echo "  агент  → $ZCODE_AGENTS_DIR/$(basename "$f") , $CLAUDE_AGENTS_DIR/$(basename "$f")"
done
echo "  журнал → $STATE_ROOT/state/{runs,out} (env SR_STATE_ROOT переопределяет)"
