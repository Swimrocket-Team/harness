#!/usr/bin/env bash
#
# install.command — установка ассистента «Репутация» двойным кликом (macOS).
# Находит свою папку, запускает install.sh из неё и объясняет, что делать дальше.
# Написан человеческим языком: менеджер не знает термина.

set -u

DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"

echo "Ассистент «Репутация» — установка"
echo "--------------------------------"
echo "Эта программа настроит команду /sr-reputation в приложениях"
echo "Claude Code и Z-Code на этом компьютере."
echo ""
printf "Чтобы установить, введи 1 и нажми Enter (любое другое — отмена): "
read -r ANSWER
if [ "$ANSWER" != "1" ]; then
  echo ""
  echo "Отменено. Ничего не установлено и не изменено."
  echo ""
  read -r -p "Нажми Enter, чтобы закрыть это окно" _
  exit 0
fi

# install.sh лежит рядом (в распакованном архиве) или тремя папками выше (в репо).
if [ -f "$DIR/install.sh" ]; then
  bash "$DIR/install.sh"
elif [ -f "$DIR/../../../install.sh" ]; then
  bash "$DIR/../../../install.sh"
else
  echo ""
  echo "Не нашла установщик (файл install.sh) рядом с этим файлом."
  echo "Похоже, при распаковке архив распался. Распакуй архив заново:"
  echo "дважды кликни по архиву — появится папка, и запускай install.command из неё."
  echo ""
  echo "Если не получается — напиши Мише."
  echo ""
  read -r -p "Нажми Enter, чтобы закрыть это окно" _
  exit 1
fi

RESULT=$?

echo ""
if [ "$RESULT" = "0" ]; then
  echo "Готово!"
  echo "Теперь:"
  echo "  1. Открой программу Claude Code (или Z-Code)."
  echo "  2. Набери в строке /sr-reputation и нажми Enter."
  echo ""
  echo "Если что-то не так — в папке установки открой"
  echo "skills/sr-reputation/scripts и дважды кликни doctor.command,"
  echo "а потом пришли Мише то, что он покажет."
else
  echo "Установка не прошла. Напиши Мише и пришли ему то, что напечатано выше."
fi
echo ""
read -r -p "Нажми Enter, чтобы закрыть это окно" _
exit $RESULT
