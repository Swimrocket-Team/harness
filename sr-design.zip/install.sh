#!/usr/bin/env bash
#
# install.sh — установка ассистента «Дизайн» (скилл sr-design + 5 общих агентов sr-*)
# в хосты Z-Code и Claude Code. Ставит ТОЛЬКО sr-design и общих агентов sr-*;
# существующие установки других ассистентов и их журналы не трогает.
#
# Использование:
#   bash install.sh              # установить (идемпотентно)
#   bash install.sh --uninstall  # удалить скилл и агентов (журналы не трогает)
#
# Работает из двух раскладок:
#   бандл:  install.sh лежит рядом с skills/sr-design/ и agents/
#   репо:   install.sh лежит внутри скилла, агенты — тремя папками выше (../../agents)
#
# Целевые точки (4):
#   ~/.zcode/skills/sr-design/   ~/.claude/skills/sr-design/
#   ~/.zcode/agents/sr-*.md      ~/.claude/agents/sr-*.md
#
# Журнал прогонов (STATE_ROOT) — вне целевых каталогов, один на оба хоста:
#   $SR_STATE_ROOT или ~/.sr-harness/sr-design
#
# Что нужно помощнику (проверяем и сообщаем по-человечески, установку НЕ блокируем):
#   форматы — sips (встроен в macOS); макеты — Google Chrome.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# --- источники: бандл или репо -----------------------------------------------
if [ -d "$SCRIPT_DIR/skills/sr-design" ]; then
  SKILL_SRC="$SCRIPT_DIR/skills/sr-design"           # бандл
else
  SKILL_SRC="$SCRIPT_DIR"                            # репо (install.sh внутри скилла)
fi
AGENTS_SRC="$SCRIPT_DIR/agents"
[ -d "$AGENTS_SRC" ] || AGENTS_SRC="$SCRIPT_DIR/../../agents"

ZCODE_SKILL_DIR="$HOME/.zcode/skills/sr-design"
CLAUDE_SKILL_DIR="$HOME/.claude/skills/sr-design"
ZCODE_AGENTS_DIR="$HOME/.zcode/agents"
CLAUDE_AGENTS_DIR="$HOME/.claude/agents"

STATE_ROOT="${SR_STATE_ROOT:-$HOME/.sr-harness/sr-design}"

fail() { echo "ERROR: $*" >&2; exit 1; }

[ -f "$SKILL_SRC/SKILL.md" ] || fail "нет $SKILL_SRC/SKILL.md — распакуй архив целиком и запускай из его папки"
[ -f "$SKILL_SRC/scripts/reformat.sh" ] || fail "нет $SKILL_SRC/scripts/reformat.sh — распакуй архив целиком"
[ -f "$SKILL_SRC/templates/sizes.json" ] || fail "нет $SKILL_SRC/templates/sizes.json"

# --- uninstall ---------------------------------------------------------------
if [ "${1:-}" = "--uninstall" ]; then
  rm -rf "$ZCODE_SKILL_DIR" "$CLAUDE_SKILL_DIR"
  for host in "$ZCODE_AGENTS_DIR" "$CLAUDE_AGENTS_DIR"; do
    for f in "$AGENTS_SRC"/sr-*.md; do
      rm -f "$host/$(basename "$f")"
    done
  done
  echo "Удалено:"
  echo "  - $ZCODE_SKILL_DIR"
  echo "  - $CLAUDE_SKILL_DIR"
  echo "  - sr-*.md из $ZCODE_AGENTS_DIR и $CLAUDE_AGENTS_DIR"
  echo "Журнал не тронут (прогоны остались): $STATE_ROOT"
  exit 0
fi

[ "${1:-}" = "" ] || fail "неизвестный флаг: $1 (доступен только --uninstall)"

# --- install: скилл в два хоста ----------------------------------------------
for dest in "$ZCODE_SKILL_DIR" "$CLAUDE_SKILL_DIR"; do
  mkdir -p "$(dirname "$dest")"
  rm -rf "$dest"
  cp -R "$SKILL_SRC" "$dest"
  rm -rf "$dest/state"   # журнал — только в STATE_ROOT, не в скилле
  # Права на запуск могли потеряться при распаковке архива — выставляем явно.
  find "$dest" -type f \( -name '*.sh' -o -name '*.command' \) -exec chmod +x {} +
done

# --- install: общие агенты sr-* в два хоста ----------------------------------
shopt -s nullglob
agent_files=("$AGENTS_SRC"/sr-*.md)
[ "${#agent_files[@]}" -gt 0 ] || fail "в $AGENTS_SRC нет файлов sr-*.md — распакуй архив целиком"
for host in "$ZCODE_AGENTS_DIR" "$CLAUDE_AGENTS_DIR"; do
  mkdir -p "$host"
  for f in "${agent_files[@]}"; do
    cp "$f" "$host/"
  done
done
shopt -u nullglob

# --- STATE_ROOT: журнал прогонов ----------------------------------------------
mkdir -p "$STATE_ROOT/state/runs" "$STATE_ROOT/state/out"

echo "Установлено (идемпотентно, повторный запуск безопасен):"
echo "  скилл  → $ZCODE_SKILL_DIR"
echo "  скилл  → $CLAUDE_SKILL_DIR"
for f in "${agent_files[@]}"; do
  echo "  агент  → $ZCODE_AGENTS_DIR/$(basename "$f") , $CLAUDE_AGENTS_DIR/$(basename "$f")"
done
echo "  журнал → $STATE_ROOT/state/{runs,out}"

# --- что нужно помощнику: проверяем окружение, установку НЕ блокируем ----------
echo ""
echo "Проверка окружения (некритично, можно доустановить позже):"
if command -v sips >/dev/null 2>&1; then
  echo "  форматы (sips): ок — встроен в macOS"
else
  echo "  форматы (sips): НЕ НАЙДЕН — нужен macOS; форматы работать не будут"
fi
CHROME_PATH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
if [ -x "$CHROME_PATH" ]; then
  echo "  макеты (Chrome): ок — $CHROME_PATH"
elif command -v chromium >/dev/null 2>&1; then
  echo "  макеты (chromium): ок — $(command -v chromium)"
else
  echo "  макеты (Chrome): НЕ НАЙДЕН — поставь Google Chrome с google.com/chrome,"
  echo "                   без него форматы работают, макеты — нет"
fi
