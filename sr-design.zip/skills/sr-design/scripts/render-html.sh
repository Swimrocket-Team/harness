#!/usr/bin/env bash
#
# render-html.sh — рендер бренд-шаблонов sr-design в PNG всех размеров
# (templates/sizes.json). HTML-шаблон + JSON-данные человека → инъекция бренд-цветов
# (brand/colors.json) и данных по плейсхолдерам {{KEY}} → headless-скриншот каждого
# размера в ./results/.
#
# Использование:
#   bash render-html.sh <шаблон.html> <данные.json> [--sizes post,story,...] \
#                      [--out DIR] [--json]
#
#   --sizes   список размеров из templates/sizes.json через запятую (не задан — все)
#   --out     папка результатов (по умолчанию ./results); <шаблон>-<размер>.png
#   --json    машиночитаемый отчёт вместо человеческого списка
#
# Рендер-движок (первый найденный):
#   1. Google Chrome: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
#      (перекрывается env SR_CHROME_BIN; проверяется и chromium/chromium-browser из PATH)
#   2. playwright (модуль python3)
#   Ничего не найдено → setup_required + подсказка поставить Chrome; exit 0.
#
# Плейсхолдеры шаблона:
#   {{C_PRIMARY}} {{C_DARK}} {{C_LIGHT}} {{C_ACCENT}} {{C_TEXT}} — бренд-цвета
#   {{W}} {{H}} {{SIZE}} — размер рендера; {{ключ}} — поле из данных человека
#   Чего-то нет в данных → {{ключ}} заменяется пустотой + пометка в отчёте
#   (анти-галлюцинация: пробел не заполняется выдумкой).
#
# Никогда не падает с ненулевым кодом (кроме неверного использования — exit 2):
# ничего не получилось — честный статус nothing_done / setup_required, exit 0.

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
COLORS_JSON="$SKILL_DIR/brand/colors.json"
SIZES_JSON="$SKILL_DIR/templates/sizes.json"
CHROME_DEFAULT="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

usage() {
  echo "Использование: bash render-html.sh <шаблон.html> <данные.json> [--sizes ...] [--out DIR] [--json]" >&2
  exit 2
}

setup_required() {  # $1 — чего не хватает; $2 — подсказка (опционально)
  local why="$1" hint="${2:-}"
  if [ "${JSON_OUT:-0}" = "1" ]; then
    printf '{"status":"setup_required","reason":"%s","done":[],"skipped":[]}\n' "$why"
  else
    echo "setup_required: $why"
    [ -n "$hint" ] && echo "Подсказка: $hint"
    echo "Ничего не сделано, ничего не сломано. Устрани — и повтори."
  fi
  exit 0
}

# --- аргументы -----------------------------------------------------------------
TPL=""; DATA=""; SIZES=""; OUTDIR="results"; JSON_OUT=0
while [ $# -gt 0 ]; do
  case "$1" in
    --sizes) [ $# -ge 2 ] || usage; SIZES="$2"; shift 2 ;;
    --out)   [ $# -ge 2 ] || usage; OUTDIR="$2"; shift 2 ;;
    --json)  JSON_OUT=1; shift ;;
    -h|--help) usage ;;
    -*) usage ;;
    *) if [ -z "$TPL" ]; then TPL="$1"; elif [ -z "$DATA" ]; then DATA="$1"; else usage; fi; shift ;;
  esac
done
[ -n "$TPL" ] && [ -n "$DATA" ] || usage
export JSON_OUT

# --- честные проверки -----------------------------------------------------------
[ -f "$TPL" ] || setup_required "не найден шаблон: $TPL"
case "${TPL##*.}" in html|htm) ;; *) setup_required "шаблон должен быть .html: $TPL" ;; esac
[ -f "$DATA" ] || setup_required "не найден файл данных: $DATA"
python3 -c "import json,sys;json.load(open(sys.argv[1]))" "$DATA" 2>/dev/null \
  || setup_required "файл данных не читается (сломанный JSON?): $DATA"
[ -f "$COLORS_JSON" ] || setup_required "не найден brand/colors.json — распакуй скилл целиком"
[ -f "$SIZES_JSON" ] || setup_required "не найден templates/sizes.json — распакуй скилл целиком"

ALL_KEYS="$(python3 -c "import json;print(' '.join(json.load(open('$SIZES_JSON')).keys()))" 2>/dev/null)" \
  || setup_required "templates/sizes.json не читается (сломанный JSON?)"

if [ -n "$SIZES" ]; then
  SIZES="${SIZES//,/ }"
  for s in $SIZES; do
    case " $ALL_KEYS " in
      *" $s "*) ;;
      *) setup_required "размер «${s}» не найден в templates/sizes.json (есть: ${ALL_KEYS// /, })" ;;
    esac
  done
  WANTED="$SIZES"
else
  WANTED="$ALL_KEYS"
fi
[ -n "$WANTED" ] || setup_required "список размеров пуст"

# единицы рендера: "размер|ширина|высота" по строкам
UNITS="$(python3 - "$SIZES_JSON" "$WANTED" <<'PYEOF'
import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
wanted = sys.argv[2].split()
print("\n".join("%s|%d|%d" % (k, d[k]["w"], d[k]["h"]) for k in wanted if k in d))
PYEOF
)" || UNITS=""
[ -n "$UNITS" ] || setup_required "не удалось прочитать размеры из templates/sizes.json"

# --- детект рендер-движка -------------------------------------------------------
# SR_CHROME_BIN — авторитетное перекрытие: задан → используется только он
# (не исполняемый → честный setup_required; так же тестируется ветка «Chrome нет»).
ENGINE=""; CHROME_BIN=""
if [ -n "${SR_CHROME_BIN:-}" ]; then
  if [ -x "$SR_CHROME_BIN" ]; then
    ENGINE="chrome"; CHROME_BIN="$SR_CHROME_BIN"
  else
    setup_required "SR_CHROME_BIN задан, но это не исполняемый файл: $SR_CHROME_BIN"
  fi
fi
if [ -z "$ENGINE" ] && [ -x "$CHROME_DEFAULT" ]; then
  ENGINE="chrome"; CHROME_BIN="$CHROME_DEFAULT"
fi
if [ -z "$ENGINE" ]; then
  for c in chromium chromium-browser; do
    if command -v "$c" >/dev/null 2>&1; then ENGINE="chrome"; CHROME_BIN="$(command -v "$c")"; break; fi
  done
fi
if [ -z "$ENGINE" ] && python3 -c "import playwright" 2>/dev/null; then
  ENGINE="playwright"
fi
if [ -z "$ENGINE" ]; then
  setup_required "не нашлось ни Google Chrome, ни chromium, ни playwright — нечем собрать картинку из шаблона" \
    "поставь Google Chrome с google.com/chrome (обычная установка) и повтори; ставит человек, ассистент ничего не устанавливает"
fi

mkdir -p "$OUTDIR"; OUTDIR="$(cd "$OUTDIR" && pwd)"
TPL_BASE="$(basename "$TPL")"; TPL_BASE="${TPL_BASE%.*}"

WORK="$(mktemp -d "${TMPDIR:-/tmp}/sr-render.XXXXXX")"
DONE_LIST="$WORK/done.txt"; SKIP_LIST="$WORK/skip.txt"; WARN_LIST="$WORK/warn.txt"
: > "$DONE_LIST"; : > "$SKIP_LIST"; : > "$WARN_LIST"
# временный HTML кладём в скилл рядом с brand/ — чтобы <img src="brand/logo.png"> резолвился
TMPHTML="$SKILL_DIR/.render-${$}-TEMP.html"
cleanup() { rm -f "$SKILL_DIR"/.render-"${$}"-*.html "$DONE_LIST" "$SKIP_LIST" "$WARN_LIST"; rmdir "$WORK" 2>/dev/null || true; }
trap cleanup EXIT

while IFS= read -r unit; do
  [ -n "$unit" ] || continue
  size="${unit%%|*}"; rest="${unit#*|}"; w="${rest%%|*}"; h="${rest#*|}"
  tmphtml="${TMPHTML/TEMP/$size}"
  if ! python3 - "$TPL" "$COLORS_JSON" "$DATA" "$tmphtml" "$size" "$w" "$h" "$WARN_LIST" <<'PYEOF'
import json, re, sys
tpl_path, colors_path, data_path, out_path, size, w, h, warn_path = sys.argv[1:9]
tpl = open(tpl_path, encoding="utf-8").read()
colors = json.load(open(colors_path, encoding="utf-8"))
data = json.load(open(data_path, encoding="utf-8"))
for key, val in colors.items():
    tpl = tpl.replace("{{C_" + key.upper() + "}}", str(val))
tpl = tpl.replace("{{W}}", str(w)).replace("{{H}}", str(h)).replace("{{SIZE}}", size)
for key, val in data.items():
    tpl = tpl.replace("{{" + key + "}}", str(val))
leftover = sorted(set(re.findall(r"\{\{([A-Za-z0-9_\-]+)\}\}", tpl)))
if leftover:
    with open(warn_path, "a", encoding="utf-8") as f:
        for k in leftover:
            f.write(size + "|" + k + "|нет в данных — оставлено пустым\n")
    tpl = re.sub(r"\{\{[A-Za-z0-9_\-]+\}\}", "", tpl)
with open(out_path, "w", encoding="utf-8") as f:
    f.write(tpl)
PYEOF
  then
    echo "$TPL_BASE|$size|инъекция данных не удалась" >> "$SKIP_LIST"
    rm -f "$tmphtml"
    continue
  fi

  out="$OUTDIR/${TPL_BASE}-${size}.png"
  case "$ENGINE" in
    chrome)
      "$CHROME_BIN" --headless=new --disable-gpu --hide-scrollbars \
        --default-background-color=FFFFFFFF \
        --window-size="$w,$h" --screenshot="$out" \
        "file://$tmphtml" >/dev/null 2>&1
      ;;
    playwright)
      SR_OUT="$out" SR_HTML="file://$tmphtml" SR_W="$w" SR_H="$h" python3 - <<'PYEOF'
import os
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_page(viewport={"width": int(os.environ["SR_W"]), "height": int(os.environ["SR_H"])})
    page.goto(os.environ["SR_HTML"])
    page.screenshot(path=os.environ["SR_OUT"])
    b.close()
PYEOF
      ;;
  esac

  if [ -s "$out" ]; then
    echo "$TPL_BASE|$size|$out" >> "$DONE_LIST"
  else
    echo "$TPL_BASE|$size|рендер не создал файл (движок: $ENGINE)" >> "$SKIP_LIST"
  fi
  rm -f "$tmphtml"
done <<< "$UNITS"

# --- отчёт -----------------------------------------------------------------------
if [ "$JSON_OUT" = "1" ]; then
  SRV_ENGINE="$ENGINE" SRV_OUTDIR="$OUTDIR" SRV_DONE="$DONE_LIST" SRV_SKIP="$SKIP_LIST" SRV_WARN="$WARN_LIST" \
  python3 - <<'PYEOF'
import json, os
def read_list(path):
    try:
        with open(path, encoding="utf-8") as f:
            return [l.rstrip("\n") for l in f if l.strip()]
    except FileNotFoundError:
        return []
done = []
for line in read_list(os.environ["SRV_DONE"]):
    a, b, c = line.split("|", 2)
    done.append({"template": a, "size": b, "file": c,
                 "bytes": os.path.getsize(c) if os.path.exists(c) else 0})
skipped = []
for line in read_list(os.environ["SRV_SKIP"]):
    parts = line.split("|", 2)
    skipped.append({"template": parts[0], "size": parts[1] if len(parts) > 2 else "",
                    "reason": parts[-1]})
warnings = []
for line in read_list(os.environ["SRV_WARN"]):
    parts = line.split("|", 2)
    warnings.append({"size": parts[0], "field": parts[1],
                     "reason": parts[2] if len(parts) > 2 else ""})
print(json.dumps({"status": "ok" if done else "nothing_done",
                  "engine": os.environ["SRV_ENGINE"],
                  "outdir": os.environ["SRV_OUTDIR"],
                  "done": done, "skipped": skipped, "warnings": warnings},
                 ensure_ascii=False, indent=1))
PYEOF
else
  n_done="$(grep -c . "$DONE_LIST" 2>/dev/null)"; n_done="${n_done:-0}"
  n_skip="$(grep -c . "$SKIP_LIST" 2>/dev/null)"; n_skip="${n_skip:-0}"
  echo "Готово: картинок сделано — $n_done, пропущено — $n_skip (движок: $ENGINE)"
  while IFS='|' read -r a b c; do [ -n "$a" ] && echo "  ok: $a → $c ($b)"; done < "$DONE_LIST"
  while IFS='|' read -r a b c; do [ -n "$a" ] && echo "  пропуск: $a ($b) — $c"; done < "$SKIP_LIST"
  while IFS='|' read -r s k r; do [ -n "$s" ] && echo "  пусто: ${s}: поле ${k} — оставлено пустым"; done < "$WARN_LIST"
  [ "$n_done" -gt 0 ] && echo "Папка результатов: $OUTDIR"
fi
exit 0
