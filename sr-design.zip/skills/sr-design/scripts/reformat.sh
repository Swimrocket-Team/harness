#!/usr/bin/env bash
#
# reformat.sh — переработка принесённых изображений под площадки школы (скилл sr-design).
# Для каждого входного изображения и каждого размера из templates/sizes.json делает
# версию ровно нужного размера: пропорциональное масштабирование «в покрышке»
# (sips -z, чтобы обе стороны стали не меньше целевых) + кроп по центру (sips -c).
# Ничего не дорисовывает и не растягивает; исходные файлы только читает.
#
# Использование:
#   bash reformat.sh <файл-или-папка> [--sizes post,story,...] [--out DIR] [--json]
#
#   --sizes   список размеров из templates/sizes.json через запятую
#             (не задан — все размеры); имена: post, story, yt_cover, a4, web_banner
#   --out     папка результатов (по умолчанию ./results); файл называется
#             <имя-входа>-<размер>.png
#   --json    машиночитаемый отчёт (один JSON-объект) вместо человеческого списка
#
# Инструменты: только sips (встроен в macOS). sips отсутствует (не-macOS) →
# setup_required, честный статус, exit 0. Ошибка одного файла — файл пропускается
# с пометкой, остальные обрабатываются; ничего не получилось — честный статус
# nothing_done; скрипт не падает (exit 0), только неверное использование — exit 2.

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SIZES_JSON="$SKILL_DIR/templates/sizes.json"

usage() {
  echo "Использование: bash reformat.sh <файл-или-папка> [--sizes post,story,...] [--out DIR] [--json]" >&2
  exit 2
}

setup_required() {  # $1 — чего не хватает; честный статус, exit 0
  local why="$1"
  if [ "${JSON_OUT:-0}" = "1" ]; then
    printf '{"status":"setup_required","reason":"%s","done":[],"skipped":[]}\n' "$why"
  else
    echo "setup_required: $why"
    echo "Ничего не сделано, ничего не сломано. Устрани — и повтори."
  fi
  exit 0
}

# --- аргументы -----------------------------------------------------------------
INPUT=""; SIZES=""; OUTDIR="results"; JSON_OUT=0
while [ $# -gt 0 ]; do
  case "$1" in
    --sizes) [ $# -ge 2 ] || usage; SIZES="$2"; shift 2 ;;
    --out)   [ $# -ge 2 ] || usage; OUTDIR="$2"; shift 2 ;;
    --json)  JSON_OUT=1; shift ;;
    -h|--help) usage ;;
    -*) usage ;;
    *) [ -z "$INPUT" ] || usage; INPUT="$1"; shift ;;
  esac
done
[ -n "$INPUT" ] || usage
export JSON_OUT

# --- честные проверки окружения ------------------------------------------------
command -v sips >/dev/null 2>&1 || setup_required "нужна программа sips (встроена в macOS); на этом компьютере её нет"
[ -f "$SIZES_JSON" ] || setup_required "не найден templates/sizes.json — распакуй скилл целиком"

ALL_KEYS="$(python3 -c "import json;print(' '.join(json.load(open('$SIZES_JSON')).keys()))" 2>/dev/null)" \
  || setup_required "templates/sizes.json не читается (сломанный JSON?)"

if [ -n "$SIZES" ]; then
  SIZES="${SIZES//,/ }"
  for s in $SIZES; do
    case " $ALL_KEYS " in
      *" $s "*) ;;
      *) setup_required "размер «${s}» не найден в templates/sizes.json (есть: ${ALL_KEYS// /, })" ;;
    esac
  done
  SIZE_KEYS="$SIZES"
else
  SIZE_KEYS="$ALL_KEYS"
fi
[ -n "$SIZE_KEYS" ] || setup_required "список размеров пуст"

# --- вход: файл или папка -------------------------------------------------------
FILES=()
if [ -f "$INPUT" ]; then
  FILES+=("$INPUT")
elif [ -d "$INPUT" ]; then
  shopt -s nullglob
  for f in "$INPUT"/*; do
    ext="${f##*.}"; ext="$(echo "$ext" | tr '[:upper:]' '[:lower:]')"
    case "$ext" in
      png|jpg|jpeg|tif|tiff|heic|gif|bmp) FILES+=("$f") ;;
    esac
  done
  shopt -u nullglob
else
  setup_required "не найден вход: $INPUT (укажи существующий файл или папку)"
fi
[ "${#FILES[@]}" -gt 0 ] || setup_required "в $INPUT нет изображений (png/jpg/jpeg/tif/tiff/heic/gif/bmp)"

mkdir -p "$OUTDIR"

# --- обработка ------------------------------------------------------------------
WORK="$(mktemp -d "${TMPDIR:-/tmp}/sr-reformat.XXXXXX")"
DONE_LIST="$WORK/done.txt"; SKIP_LIST="$WORK/skip.txt"; : > "$DONE_LIST"; : > "$SKIP_LIST"
trap 'rm -rf "$WORK"' EXIT

while IFS= read -r -d '' src; do
  base="${src##*/}"; base="${base%.*}"
  # размеры источника
  sw="$(sips -g pixelWidth "$src" 2>/dev/null | awk '/pixelWidth/{print $2}')"
  sh="$(sips -g pixelHeight "$src" 2>/dev/null | awk '/pixelHeight/{print $2}')"
  # строго положительное целое: sips на битом файле может отдать <nil> или пусто
  dims_ok=1
  for v in "$sw" "$sh"; do
    case "$v" in ""|0|*[!0-9]*) dims_ok=0 ;; esac
  done
  if [ "$dims_ok" = "0" ]; then
    for s in $SIZE_KEYS; do echo "$base|$s|не удалось прочитать размеры (не изображение?)" >> "$SKIP_LIST"; done
    continue
  fi
  for s in $SIZE_KEYS; do
    read -r tw th < <(python3 -c "import json;d=json.load(open('$SIZES_JSON'))['$s'];print(d['w'],d['h'])")
    # «покрышка»: пропорционально масштабируем так, чтобы обе стороны >= целевых
    if [ "$((sw * th))" -gt "$((tw * sh))" ]; then
      cover_h="$th"; cover_w=$(( sw * th / sh ))
    else
      cover_w="$tw"; cover_h=$(( sh * tw / sw ))
    fi
    [ "$cover_w" -lt "$tw" ] && cover_w="$tw"
    [ "$cover_h" -lt "$th" ] && cover_h="$th"
    tmp="$WORK/${base}-${s}.png"
    if ! sips -z "$cover_h" "$cover_w" "$src" --out "$tmp" >/dev/null 2>&1; then
      echo "$base|$s|sips не смог масштабировать" >> "$SKIP_LIST"; continue
    fi
    # кроп по центру до точного размера (если стороны уже равны — no-op)
    if ! sips -c "$th" "$tw" "$tmp" --out "$tmp" >/dev/null 2>&1; then
      echo "$base|$s|sips не смог обрезать" >> "$SKIP_LIST"; continue
    fi
    dest="$OUTDIR/${base}-${s}.png"
    if ! sips -s format png "$tmp" --out "$dest" >/dev/null 2>&1; then
      echo "$base|$s|не удалось записать $dest" >> "$SKIP_LIST"; continue
    fi
    echo "$base|$s|$dest" >> "$DONE_LIST"
  done
done < <(for f in "${FILES[@]}"; do printf '%s\0' "$f"; done)

# --- отчёт -----------------------------------------------------------------------
if [ "$JSON_OUT" = "1" ]; then
  python3 - "$OUTDIR" "$DONE_LIST" "$SKIP_LIST" <<PYEOF
import json, os, sys
outdir = os.path.abspath(sys.argv[1])
def read_list(path):
    try:
        with open(path, encoding="utf-8") as f:
            return [l.rstrip("\n") for l in f if l.strip()]
    except FileNotFoundError:
        return []
done = []
for line in read_list(sys.argv[2]):
    a, b, c = line.split("|", 2)
    done.append({"input": a, "size": b, "file": c,
                 "bytes": os.path.getsize(c) if os.path.exists(c) else 0})
skipped = []
for line in read_list(sys.argv[3]):
    a, b, c = line.split("|", 2)
    skipped.append({"input": a, "size": b, "reason": c})
print(json.dumps({"status": "ok" if done else "nothing_done",
                  "outdir": outdir, "done": done, "skipped": skipped},
                 ensure_ascii=False, indent=1))
PYEOF
else
  n_done="$(grep -c . "$DONE_LIST" 2>/dev/null)"; n_done="${n_done:-0}"
  n_skip="$(grep -c . "$SKIP_LIST" 2>/dev/null)"; n_skip="${n_skip:-0}"
  echo "Готово: файлов сделано — $n_done, пропущено — $n_skip"
  while IFS='|' read -r a b c; do [ -n "$a" ] && echo "  ok: $a → $c ($b)"; done < "$DONE_LIST"
  while IFS='|' read -r a b c; do [ -n "$a" ] && echo "  пропуск: $a ($b) — $c"; done < "$SKIP_LIST"
  [ "$n_done" -gt 0 ] && echo "Папка результатов: $(cd "$OUTDIR" && pwd)"
fi
exit 0
