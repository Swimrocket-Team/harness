#!/usr/bin/env bash
#
# smoke.sh — smoke-гейт скилла sr-design (план 05-09). Запуск из корня репо
# SwimRocket (или из бандла — корни вычисляются).
#
# Флаги:
#   (без флагов)   базовый набор: структура скилла (SKILL/AGENTS/ONBOARDING/README/
#                  install×2/update/VERSION/scripts×3/brand/templates×4)
#   --skill        + frontmatter SKILL.md, три сценария, периметр, STATE_ROOT
#   --scripts      + bash -n всех скриптов, пути замены sr-sync, без секретов
#   --install      + install.sh: только sr-design (негативный grep), --uninstall,
#                    install.command/update.command исполняемые и на месте
#   --install-home + изолированный HOME (mktemp): install → структура →
#                    идемпотентен → uninstall чистит, журнал остаётся
#   --live         + факт-прогоны: reformat на сгенерированном PNG (sips, точный
#                    размер), render announce.html (Chrome есть → PNG >10KB;
#                    нет → SKIP), ветка «Chrome отсутствует» → setup_required exit 0,
#                    sr-sync fail-путь и путь замены (file://-архив)
#   --router       + маршрутизатор: AGENTS.md содержит все 4 скилла и фразу
#                    «если не уверена», README-МАРШРУТ.md на месте
#   --checklist    + CHECKLIST.md: плейсхолдеры Д1–Д6 (до встречи — пустые [ ])
#   --full         всё выше
#
# Путь состояния: env SR_STATE_ROOT (для тестов подставляется временный каталог),
# по умолчанию ~/.sr-harness/sr-design.

set -euo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SELF_DIR/.." && pwd)"
REPO_ROOT="$(cd "$SKILL_DIR/../../.." && pwd)"

# Агенты/маршрутизатор: в репо — managers/agents, в бандле — agents/ рядом с skills/.
if [ -d "$REPO_ROOT/managers/agents" ]; then
  AGENTS_DIR="$REPO_ROOT/managers/agents"
elif [ -d "$SKILL_DIR/../../agents" ]; then
  AGENTS_DIR="$(cd "$SKILL_DIR/../../agents" && pwd)"
else
  AGENTS_DIR=""
fi
CHECKLIST="$SKILL_DIR/tests/CHECKLIST.md"

ERRORS=0
ok()  { echo "  ok: $1"; }
err() { echo "  FAIL: $1" >&2; ERRORS=$((ERRORS + 1)); }
header() { echo "== $1 =="; }

mkpng() {  # $1 = путь; валидный PNG 64×64 встроенным python (zlib/struct, ноль зависимостей)
  python3 - "$1" <<'PYEOF'
import zlib, struct, sys
w = h = 64
raw = b"".join(b"\x00" + b"\x00\x66\xcc" * w for _ in range(h))
def ch(t, d):
    c = t + d
    return struct.pack(">I", len(d)) + c + struct.pack(">I", zlib.crc32(c) & 0xffffffff)
png = (b"\x89PNG\r\n\x1a\n"
       + ch(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
       + ch(b"IDAT", zlib.compress(raw)) + ch(b"IEND", b""))
open(sys.argv[1], "wb").write(png)
PYEOF
}

basic_checks() {
  header "базовый набор (структура скилла)"
  local f
  for f in SKILL.md AGENTS.md ONBOARDING.md README-СТАРТ.md install.sh install.command \
           update.command VERSION brand/colors.json brand/README-БРЕНД.md \
           templates/afisha.html templates/card.html templates/announce.html \
           templates/sizes.json scripts/reformat.sh scripts/render-html.sh \
           scripts/sr-sync.sh; do
    [ -f "$SKILL_DIR/$f" ] && ok "$f" || err "нет $f"
  done
  [ -f "$SKILL_DIR/tests/smoke.sh" ] && ok "tests/smoke.sh" || err "нет tests/smoke.sh"
  python3 -c "import json,sys;json.load(open('$SKILL_DIR/brand/colors.json'));json.load(open('$SKILL_DIR/templates/sizes.json'))" 2>/dev/null \
    && ok "colors.json и sizes.json — валидный JSON" || err "JSON не читается (colors/sizes)"
}

skill_checks() {
  header "--skill"
  local fm="$SKILL_DIR/SKILL.md"
  grep -q '^name: sr-design' "$fm" && ok "frontmatter name: sr-design" || err "frontmatter без name: sr-design"
  grep -q '^description:' "$fm" && ok "frontmatter description" || err "frontmatter без description"
  grep -q '^allowed-tools:' "$fm" && ok "frontmatter allowed-tools" || err "frontmatter без allowed-tools"
  local w
  for w in "Сценарий 1" "Сценарий 2" "Сценарий 3" "«форматы»" "«макет»" "«бриф»" \
           "reformat.sh" "render-html.sh" "sizes.json" "colors.json" \
           "sr-harness/sr-design" "Файлы только в рабочую папку"; do
    grep -q "$w" "$fm" && ok "SKILL.md содержит «${w}»" || err "SKILL.md без «${w}»"
  done
  # периметр: публикация — человек
  grep -q "публикует и" "$SKILL_DIR/README-СТАРТ.md" || grep -q "публикуешь" "$SKILL_DIR/README-СТАРТ.md" \
    && ok "README-СТАРТ: публикация — человек" || err "README-СТАРТ: нет периметра «публикуешь сам»"
}

scripts_checks() {
  header "--scripts"
  local s
  for s in reformat.sh render-html.sh sr-sync.sh; do
    bash -n "$SKILL_DIR/scripts/$s" && ok "$s: синтаксис валиден" || err "$s: синтаксис сломан"
  done
  grep -q "SR_HARNESS_REPO_URL" "$SKILL_DIR/scripts/sr-sync.sh" \
    && ok "sr-sync.sh: вшитая константа SR_HARNESS_REPO_URL" || err "sr-sync.sh: нет SR_HARNESS_REPO_URL"
  if grep -E "sr-sync.sh" "$SKILL_DIR/scripts/sr-sync.sh" | grep -qE "token|TOKEN|ghp_|секрет"; then
    err "sr-sync.sh: похоже, есть секреты"
  else
    ok "sr-sync.sh: без секретов (публичный URL, токен не нужен)"
  fi
  grep -q 'skills/sr-design/scripts/sr-sync.sh' "$SKILL_DIR/update.command" \
    && ok "update.command: знает бандл-раскладку (skills/sr-design/scripts/)" \
    || err "update.command: нет бандл-раскладки"
  grep -q 'sr-design.zip' "$SKILL_DIR/scripts/sr-sync.sh" \
    && ok "sr-sync.sh: качает sr-design.zip" || err "sr-sync.sh: не тот архив"
}

install_checks() {
  header "--install"
  bash -n "$SKILL_DIR/install.sh" && ok "install.sh: синтаксис валиден" || err "install.sh: синтаксис сломан"
  grep -q "sr-design" "$SKILL_DIR/install.sh" && ok "install.sh про sr-design" \
    || err "install.sh не упоминает sr-design"
  # негативный grep: установщик не знает других скиллов — только свои пути
  if grep -qE "sr-reputation|sr-content-day|sr-content-plan" "$SKILL_DIR/install.sh"; then
    err "install.sh упоминает чужие скиллы (должен ставить только sr-design)"
  else
    ok "install.sh без чужих путей (только sr-design)"
  fi
  grep -q -- "--uninstall" "$SKILL_DIR/install.sh" && ok "install.sh: есть --uninstall" \
    || err "install.sh без --uninstall"
  grep -q "sips" "$SKILL_DIR/install.sh" && grep -qi "chrome" "$SKILL_DIR/install.sh" \
    && ok "install.sh: проверка sips/Chrome человеческим выводом" \
    || err "install.sh: нет проверки sips/Chrome"
  [ -x "$SKILL_DIR/install.command" ] && ok "install.command исполняемый" \
    || err "install.command не исполняемый (нужен chmod +x)"
  [ -x "$SKILL_DIR/update.command" ] && ok "update.command исполняемый" \
    || err "update.command не исполняемый (нужен chmod +x)"
}

install_home_checks() {
  header "--install-home: изолированный HOME"
  local tmp; tmp=$(mktemp -d)
  # install в чистый HOME (репо-раскладка: install.sh внутри скилла)
  if HOME="$tmp" bash "$SKILL_DIR/install.sh" >/dev/null 2>&1; then
    ok "install в чистый HOME прошёл"
  else
    err "install.sh упал в изолированном HOME"
  fi
  [ -f "$tmp/.zcode/skills/sr-design/SKILL.md" ] && ok "~/.zcode/skills/sr-design создан" \
    || err "нет ~/.zcode/skills/sr-design/SKILL.md"
  [ -f "$tmp/.claude/skills/sr-design/brand/colors.json" ] && ok "~/.claude/skills/sr-design создан (с brand/)" \
    || err "нет ~/.claude/skills/sr-design/brand/colors.json"
  [ -f "$tmp/.claude/skills/sr-design/templates/sizes.json" ] \
    && ok "templates/ установлены" || err "нет templates/ в установленном"
  [ "$(ls "$tmp/.zcode/agents" 2>/dev/null | wc -l | tr -d ' ')" = "5" ] \
    && [ "$(ls "$tmp/.claude/agents" 2>/dev/null | wc -l | tr -d ' ')" = "5" ] \
    && ok "агентов sr-* по 5 в обоих хостах" || err "агентов в хостах не ровно 5"
  [ -d "$tmp/.sr-harness/sr-design/state/runs" ] \
    && [ -d "$tmp/.sr-harness/sr-design/state/out" ] \
    && ok "STATE_ROOT/state/{runs,out} создана" || err "STATE_ROOT/state/{runs,out} не создана"
  # идемпотентность
  HOME="$tmp" bash "$SKILL_DIR/install.sh" >/dev/null 2>&1 && ok "повторный install безопасен (идемпотентен)" \
    || err "повторный install упал"
  # uninstall чистит, журнал остаётся
  HOME="$tmp" bash "$SKILL_DIR/install.sh" --uninstall >/dev/null 2>&1 || err "uninstall упал"
  [ ! -e "$tmp/.zcode/skills/sr-design" ] && [ ! -e "$tmp/.claude/skills/sr-design" ] \
    && [ ! -e "$tmp/.claude/agents/sr-drafter.md" ] \
    && ok "uninstall снял скилл и агентов" || err "uninstall оставил файлы"
  [ -d "$tmp/.sr-harness/sr-design/state/runs" ] \
    && ok "журнал после uninstall остался (данные не тронуты)" \
    || err "uninstall снёс журнал"
  rm -rf "$tmp"
}

live_checks() {
  header "--live: факт-прогоны (sips/Chrome/наличие — честные SKIP)"
  local work; work=$(mktemp -d)
  # --- 1) reformat на сгенерированном PNG (как verify плана) ---
  mkpng "$work/t.png"
  local out rc=0
  out="$(cd "$work" && bash "$SKILL_DIR/scripts/reformat.sh" "$work/t.png" --sizes post --out "$work/results" 2>&1)" || rc=$?
  if [ -f "$work/results/t-post.png" ] && [ "$rc" = "0" ]; then
    local pw ph
    pw="$(sips -g pixelWidth "$work/results/t-post.png" 2>/dev/null | awk '/pixelWidth/{print $2}')"
    ph="$(sips -g pixelHeight "$work/results/t-post.png" 2>/dev/null | awk '/pixelHeight/{print $2}')"
    if [ "$pw" = "1080" ] && [ "$ph" = "1080" ]; then
      ok "reformat: results/t-post.png создан sips-ом, ровно 1080×1080"
    else
      err "reformat: размер $pw×$ph, а должен быть 1080×1080"
    fi
  else
    err "reformat: rc=$rc или нет results/t-post.png (вывод: ${out:0:120})"
  fi
  # --- 2) reformat: пакет по папке, битый файл пропускается честно ---
  mkpng "$work/ok.png"; printf 'not a png' > "$work/broken.png"
  out="$(cd "$work" && mkdir -p "$work/in" && mv "$work/ok.png" "$work/broken.png" "$work/in/" \
        && bash "$SKILL_DIR/scripts/reformat.sh" "$work/in" --sizes post,story --out "$work/results2" --json 2>&1)" || rc=$?
  if grep -q '"status": "ok"' <<< "$out" && [ "$(find "$work/results2" -name '*.png' | wc -l | tr -d ' ')" = "2" ] \
     && grep -q '"reason"' <<< "$out"; then
    ok "reformat: папка → 2 PNG (ok.png×2), broken.png пропущен с пометкой"
  else
    err "reformat папки: ожидалось 2 PNG + пометка о broken"
  fi
  # --- 3) render: Chrome есть → факт; нет → setup_required exit 0 ---
  local chrome="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
  cat > "$work/announce-data.json" <<'EOF'
{
  "title": "Открытый урок плавания",
  "text": "Приходите познакомиться с бассейном и тренерами.",
  "date": "15 ноября, суббота",
  "place": "Бассейн «Чайка»",
  "price": "Бесплатно",
  "footer": "Запись в директ"
}
EOF
  if [ -x "$chrome" ]; then
    out="$(cd "$work" && bash "$SKILL_DIR/scripts/render-html.sh" \
      "$SKILL_DIR/templates/announce.html" "$work/announce-data.json" \
      --sizes post --out "$work/results3" 2>&1)" || rc=$?
    if [ -s "$work/results3/announce-post.png" ]; then
      local bytes; bytes=$(wc -c < "$work/results3/announce-post.png" | tr -d ' ')
      if [ "$bytes" -gt 10240 ]; then
        ok "render: announce-post.png существует и >10KB ($bytes байт, Chrome)"
      else
        err "render: announce-post.png подозрительно мал ($bytes байт)"
      fi
    else
      err "render: Chrome есть, но announce-post.png не создан (rc=$rc)"
    fi
  else
    echo "  SKIP: Google Chrome не найден — факт-рендер пропущен (нужен человеку для макетов)"
  fi
  # ветка «Chrome отсутствует» через авторитетный SR_CHROME_BIN (не исполняемый)
  out="$(cd "$work" && SR_CHROME_BIN=/nonexistent/chrome bash "$SKILL_DIR/scripts/render-html.sh" \
    "$SKILL_DIR/templates/announce.html" "$work/announce-data.json" --sizes post 2>&1)" || rc=$?
  if [ "$rc" = "0" ] && grep -q "setup_required" <<< "$out"; then
    ok "render без Chrome: setup_required, exit 0, честный статус"
  else
    err "render без Chrome: rc=$rc или нет setup_required (вывод: ${out:0:120})"
  fi
  # --- 4) sr-sync: fail-путь и путь замены (изолированный HOME) ---
  local tmp; tmp=$(mktemp -d)
  mkdir -p "$tmp/.zcode/skills/sr-design"
  echo "9.9.9" > "$tmp/.zcode/skills/sr-design/VERSION"
  echo "marker-untouched" > "$tmp/.zcode/skills/sr-design/MARKER"
  out="$(HOME="$tmp" SR_SYNC_URL="https://invalid.invalid/x" bash "$SKILL_DIR/scripts/sr-sync.sh" 2>&1)" || rc=$?
  if [ "$rc" = "0" ] && grep -q "не удалось" <<< "$out"; then
    ok "sr-sync fail-путь: exit 0 + честный статус «не удалось / работает старая версия»"
  else
    err "sr-sync fail-путь: rc=$rc или нет слов «не удалось»"
  fi
  [ "$(cat "$tmp/.zcode/skills/sr-design/VERSION")" = "9.9.9" ] \
    && [ -f "$tmp/.zcode/skills/sr-design/MARKER" ] \
    && ok "sr-sync fail-путь: установленное не тронуто" || err "sr-sync fail-путь: скилл изменился"
  # путь замены: «свежий архив» 2.0.0 через file:// (curl умеет file://)
  mkdir -p "$tmp/fakebundle/skills/sr-design"
  cp "$SKILL_DIR/SKILL.md" "$tmp/fakebundle/skills/sr-design/"
  echo "2.0.0" > "$tmp/fakebundle/skills/sr-design/VERSION"
  (cd "$tmp/fakebundle" && zip -qr "$tmp/fake.zip" .) || true
  if [ -f "$tmp/fake.zip" ]; then
    out="$(HOME="$tmp" SR_SYNC_URL="file://$tmp/fake.zip" bash "$SKILL_DIR/scripts/sr-sync.sh" 2>&1)" || rc=$?
    if [ "$rc" = "0" ] && grep -q "обновлено до версии 2.0.0" <<< "$out" \
       && [ "$(cat "$tmp/.zcode/skills/sr-design/VERSION")" = "2.0.0" ]; then
      ok "sr-sync путь замены: скилл обновлён до версии из архива (2.0.0)"
    else
      err "sr-sync путь замены: rc=$rc, VERSION=$(cat "$tmp/.zcode/skills/sr-design/VERSION" 2>/dev/null)"
    fi
  else
    err "sr-sync: тестовая сборка fake.zip не удалась"
  fi
  rm -rf "$tmp" "$work"
}

router_checks() {
  header "--router: маршрутизатор 4 скиллов"
  local am="$SKILL_DIR/AGENTS.md"
  grep -q "Маршрутизатор" "$am" && ok "AGENTS.md: раздел «Маршрутизатор»" || err "AGENTS.md: нет раздела «Маршрутизатор»"
  local s
  for s in sr-reputation sr-content-day sr-content-plan sr-design; do
    grep -q "/$s" "$am" && ok "AGENTS.md: маршрут на /$s" || err "AGENTS.md: нет маршрута на /$s"
  done
  grep -q "не уверена" "$am" && ok "AGENTS.md: фраза «если не уверена — опиши задачу словами»" \
    || err "AGENTS.md: нет фразы «не уверена»"
  if [ -n "$AGENTS_DIR" ] && [ -f "$AGENTS_DIR/README-МАРШРУТ.md" ]; then
    ok "README-МАРШРУТ.md на месте ($AGENTS_DIR)"
    local r
    for r in sr-reputation sr-content-day sr-content-plan sr-design update.command; do
      grep -q "$r" "$AGENTS_DIR/README-МАРШРУТ.md" && ok "README-МАРШРУТ: упоминает $r" \
        || err "README-МАРШРУТ: нет $r"
    done
  else
    err "нет README-МАРШРУТ.md (managers/agents или agents/ в бандле)"
  fi
}

checklist_checks() {
  header "--checklist: плейсхолдеры Д1–Д6 (обкатка после встречи)"
  [ -f "$CHECKLIST" ] || { err "нет $CHECKLIST"; return; }
  grep -q "после встречи" "$CHECKLIST" && ok "шапка: обкатка после встречи на реальных материалах" \
    || err "в CHECKLIST нет пометки «после встречи»"
  local n id
  for n in 1 2 3 4 5 6; do
    id="Д$n"
    local row
    row=$(awk -F'|' -v id="$id" '{ t=$2; gsub(/ /, "", t); if (t == id) { print; exit } }' "$CHECKLIST")
    if [ -z "$row" ]; then
      err "сценарий $id не найден в CHECKLIST.md"
      continue
    fi
    case "$row" in
      *"["*"]"*) ok "$id: строка-плейсхолдер на месте" ;;
      *) err "$id: строка без чекбокса" ;;
    esac
  done
  grep -q "бренд-кит" "$CHECKLIST" && ok "CHECKLIST: «что принести» упоминает бренд-кит с Диска" \
    || err "CHECKLIST: нет «что принести» (бренд-кит)"
}

MODE="${1:-}"
case "$MODE" in
  "")
    basic_checks
    ;;
  --skill)
    basic_checks; skill_checks
    ;;
  --scripts)
    basic_checks; scripts_checks
    ;;
  --install)
    basic_checks; install_checks
    ;;
  --install-home)
    basic_checks; install_home_checks
    ;;
  --live)
    basic_checks; live_checks
    ;;
  --router)
    basic_checks; router_checks
    ;;
  --checklist)
    basic_checks; checklist_checks
    ;;
  --full)
    basic_checks
    skill_checks
    scripts_checks
    install_checks
    install_home_checks
    live_checks
    router_checks
    checklist_checks
    ;;
  *)
    echo "ERROR: неизвестный флаг: $MODE" >&2
    echo "Использование: smoke.sh [--skill|--scripts|--install|--install-home|--live|--router|--checklist|--full]" >&2
    exit 2
    ;;
esac

if [ "$ERRORS" -gt 0 ]; then
  echo "SMOKE: FAILED ($ERRORS ошибок)" >&2
  exit 1
fi
echo "SMOKE: OK"
