#!/usr/bin/env bash
#
# smoke.sh — структурный smoke-гейт скилла sr-content-day (план 05-07).
# Запуск из корня репо SwimRocket (или из бандла — корни вычисляются).
#
# Флаги:
#   (без флагов)     базовый набор: структура скилла (SKILL/algorithm/kb×7/ONBOARDING/README/install)
#   --skill          + frontmatter SKILL.md, режимы «день»/«блок»/«итог», журнал, периметр
#   --agents         все 5 агентов sr-*: name/description/tools/model:inherit,
#                    анти-галлюцинационный контракт, need_input, tools без mcp__ (NFR-5.2)
#   --install        install.sh: bash -n, ставит только sr-content-day (негативный grep),
#                    install.command на месте и исполняемый
#   --algorithm      algorithm.md = шапка-провенанс + ДОСЛОВНАЯ копия снапшота 04
#                    (diff тела с managers/algorithms/04-content-maker.md пуст)
#   --install-home   изолированный HOME (mktemp): install → структура на месте →
#                    идемпотентен → uninstall чистит, журнал остаётся
#   --checklist      CHECKLIST.md: плейсхолдеры Ч1–Ч9 по 9 блокам (до встречи — пустые [ ])
#   --full           всё выше
#
# Путь состояния: env SR_STATE_ROOT (для тестов подставляется временный каталог),
# по умолчанию ~/.sr-harness/sr-content-day.

set -euo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SELF_DIR/.." && pwd)"
REPO_ROOT="$(cd "$SKILL_DIR/../../.." && pwd)"

# Агенты: в репо — managers/agents, в бандле — agents/ рядом с skills/.
if [ -d "$REPO_ROOT/managers/agents" ]; then
  AGENTS_DIR="$REPO_ROOT/managers/agents"
elif [ -d "$SKILL_DIR/../../agents" ]; then
  AGENTS_DIR="$(cd "$SKILL_DIR/../../agents" && pwd)"
else
  AGENTS_DIR=""
fi
SNAPSHOT="$REPO_ROOT/managers/algorithms/04-content-maker.md"
CHECKLIST="$SKILL_DIR/tests/CHECKLIST.md"

ERRORS=0
ok()  { echo "  ok: $1"; }
err() { echo "  FAIL: $1" >&2; ERRORS=$((ERRORS + 1)); }
header() { echo "== $1 =="; }

kb_count() {
  [ -d "$SKILL_DIR/kb" ] && find "$SKILL_DIR/kb" -maxdepth 1 -name '*.md' | wc -l | tr -d ' ' || echo 0
}

basic_checks() {
  header "базовый набор (структура скилла)"
  [ -f "$SKILL_DIR/SKILL.md" ] && ok "SKILL.md" || err "нет SKILL.md"
  [ -f "$SKILL_DIR/algorithm.md" ] && ok "algorithm.md" || err "нет algorithm.md"
  [ -f "$SKILL_DIR/ONBOARDING.md" ] && ok "ONBOARDING.md" || err "нет ONBOARDING.md"
  [ -f "$SKILL_DIR/README-СТАРТ.md" ] && ok "README-СТАРТ.md" || err "нет README-СТАРТ.md"
  [ -f "$SKILL_DIR/install.sh" ] && ok "install.sh" || err "нет install.sh"
  [ -f "$SKILL_DIR/install.command" ] && ok "install.command" || err "нет install.command"
  local n; n=$(kb_count)
  [ "$n" = "7" ] && ok "kb/ содержит 7 файлов" || err "kb/ содержит $n файлов (нужно 7)"
}

skill_checks() {
  header "--skill"
  local fm="$SKILL_DIR/SKILL.md"
  grep -q '^name: sr-content-day' "$fm" && ok "frontmatter name: sr-content-day" || err "frontmatter без name: sr-content-day"
  grep -q '^description:' "$fm" && ok "frontmatter description" || err "frontmatter без description"
  grep -q '^allowed-tools:' "$fm" && ok "frontmatter allowed-tools" || err "frontmatter без allowed-tools"
  grep -q 'Agent' "$fm" && ok "allowed-tools содержит Agent" || err "allowed-tools без Agent"
  grep -q 'AskUserQuestion' "$fm" && ok "allowed-tools содержит AskUserQuestion" || err "allowed-tools без AskUserQuestion"
  local w
  for w in "«день»" "«блок N»" "«итог»" run_mode operator revision checker need_input \
           "sr-harness/sr-content-day" "когда что" "Частотная карта" \
           "черновик текста — публикуешь сам" "Ноль публикаций без апрува"; do
    # ${w} в фигурных скобках обязательно: bash 5.3 читает $w» как переменную «w»»
    grep -q "$w" "$fm" && ok "SKILL.md содержит «${w}»" || err "SKILL.md без «${w}»"
  done
  # периметр: кабинеты/деньги — человек; длина README ≤ 1 страницы (~35 строк)
  grep -q "Деньги, ЕРИД/маркировка, РКН — всегда человек" "$fm" \
    && ok "SKILL.md: деньги — человек" || err "SKILL.md: нет строки «Деньги, ЕРИД/маркировка, РКН — всегда человек»"
  local readme_lines; readme_lines=$(wc -l < "$SKILL_DIR/README-СТАРТ.md" | tr -d ' ')
  [ "$readme_lines" -le 40 ] && ok "README-СТАРТ.md ≤ 1 страницы ($readme_lines строк)" \
    || err "README-СТАРТ.md слишком длинный: $readme_lines строк"
  # журнал-схема: algorithm: content-maker
  grep -q '"algorithm": "content-maker"' "$fm" && ok "журнал: algorithm=content-maker" \
    || err "SKILL.md: в схеме журнала нет \"algorithm\": \"content-maker\""
}

agents_checks() {
  header "--agents"
  if [ -z "$AGENTS_DIR" ] || [ ! -d "$AGENTS_DIR" ]; then
    err "не найдена папка агентов (managers/agents или agents/ рядом с skills/)"; return
  fi
  local agents=(sr-drafter sr-editor sr-data-filler sr-checker sr-reporter)
  local found=0 a f
  for a in "${agents[@]}"; do
    f="$AGENTS_DIR/$a.md"
    if [ ! -f "$f" ]; then
      err "нет $a.md в $AGENTS_DIR"
      continue
    fi
    found=$((found + 1))
    grep -q "^name: $a" "$f" && ok "$a: name" || err "$a: frontmatter без name"
    grep -q '^description:' "$f" && ok "$a: description" || err "$a: frontmatter без description"
    grep -q '^tools:' "$f" && ok "$a: tools" || err "$a: frontmatter без tools"
    grep -q '^model: inherit' "$f" && ok "$a: model: inherit" || err "$a: без model: inherit"
    grep -q 'Не выдумывать ссылки, ID, цены, даты' "$f" \
      && ok "$a: анти-галлюцинационный контракт" \
      || err "$a: нет строки контракта «Не выдумывать ссылки, ID, цены, даты»"
    grep -q 'need_input' "$f" && ok "$a: need_input" || err "$a: без правила need_input"
    if grep '^tools:' "$f" | grep -q 'mcp__'; then
      err "$a: в tools есть mcp__ (запрещено NFR-5.2)"
    else
      ok "$a: tools без mcp__"
    fi
  done
  [ "$found" -eq 5 ] && ok "агентов ровно 5" || err "найдено агентов: $found (нужно 5)"
}

install_checks() {
  header "--install"
  bash -n "$SKILL_DIR/install.sh" && ok "install.sh: синтаксис валиден" || err "install.sh: синтаксис сломан"
  grep -q "sr-content-day" "$SKILL_DIR/install.sh" && ok "install.sh про sr-content-day" \
    || err "install.sh не упоминает sr-content-day"
  # негативный grep: установщик не знает других скиллов — только свои пути
  if grep -q "sr-reputation" "$SKILL_DIR/install.sh"; then
    err "install.sh упоминает sr-reputation (должен ставить только sr-content-day)"
  else
    ok "install.sh без чужих путей (только sr-content-day)"
  fi
  [ -x "$SKILL_DIR/install.command" ] && ok "install.command исполняемый" \
    || err "install.command не исполняемый (нужен chmod +x)"
  grep -q -- "--uninstall" "$SKILL_DIR/install.sh" && ok "install.sh: есть --uninstall" \
    || err "install.sh без --uninstall"
}

algorithm_diff_checks() {
  header "--algorithm: дословность снапшота 04"
  [ -f "$SNAPSHOT" ] || { err "нет снапшота $SNAPSHOT"; return; }
  local first_line; first_line=$(head -n 1 "$SKILL_DIR/algorithm.md")
  case "$first_line" in
    "<!--"*) ok "шапка-провенанс на месте (строка 1 — HTML-комментарий)" ;;
    *) err "первая строка algorithm.md не провенанс: $first_line" ;;
  esac
  # поиск по СТРОКЕ (here-string), а не по файлу с именем из строки
  grep -q "контент-мейкер" <<< "$first_line" && ok "провенанс: владелец — контент-мейкер (имя уточнить)" \
    || err "в провенансе нет владельца «контент-мейкер»"
  if diff <(tail -n +2 "$SKILL_DIR/algorithm.md") "$SNAPSHOT" >/dev/null 2>&1; then
    ok "тело algorithm.md дословно совпадает со снапшотом 04 (diff пуст)"
  else
    err "тело algorithm.md отличается от managers/algorithms/04-content-maker.md"
  fi
}

install_home_checks() {
  header "--install-home: изолированный HOME"
  local tmp; tmp=$(mktemp -d)
  local errors_before=$ERRORS
  # install в чистый HOME (репо-раскладка: install.sh внутри скилла)
  if HOME="$tmp" bash "$SKILL_DIR/install.sh" >/dev/null 2>&1; then
    ok "install в чистый HOME прошёл"
  else
    err "install.sh упал в изолированном HOME"
  fi
  [ -f "$tmp/.zcode/skills/sr-content-day/SKILL.md" ] && ok "~/.zcode/skills/sr-content-day создан" \
    || err "нет ~/.zcode/skills/sr-content-day/SKILL.md"
  [ -f "$tmp/.claude/skills/sr-content-day/algorithm.md" ] && ok "~/.claude/skills/sr-content-day создан" \
    || err "нет ~/.claude/skills/sr-content-day/algorithm.md"
  [ "$(ls "$tmp/.zcode/agents" 2>/dev/null | wc -l | tr -d ' ')" = "5" ] \
    && [ "$(ls "$tmp/.claude/agents" 2>/dev/null | wc -l | tr -d ' ')" = "5" ] \
    && ok "агентов sr-* по 5 в обоих хостах" || err "агентов в хостах не ровно 5"
  [ -d "$tmp/.sr-harness/sr-content-day/state/runs" ] \
    && [ -d "$tmp/.sr-harness/sr-content-day/state/out" ] \
    && ok "журнал-директория STATE_ROOT/state/{runs,out} создана" \
    || err "STATE_ROOT/state/{runs,out} не создана"
  # идемпотентность
  HOME="$tmp" bash "$SKILL_DIR/install.sh" >/dev/null 2>&1 && ok "повторный install безопасен (идемпотентен)" \
    || err "повторный install упал"
  # uninstall чистит, журнал остаётся
  HOME="$tmp" bash "$SKILL_DIR/install.sh" --uninstall >/dev/null 2>&1 || err "uninstall упал"
  [ ! -e "$tmp/.zcode/skills/sr-content-day" ] && [ ! -e "$tmp/.claude/skills/sr-content-day" ] \
    && [ ! -e "$tmp/.claude/agents/sr-drafter.md" ] \
    && ok "uninstall снял скилл и агентов" || err "uninstall оставил файлы"
  [ -d "$tmp/.sr-harness/sr-content-day/state/runs" ] \
    && ok "журнал после uninstall остался (данные не тронуты)" \
    || err "uninstall снёс журнал"
  rm -rf "$tmp"
  [ "$ERRORS" = "$errors_before" ] || true
}

checklist_checks() {
  header "--checklist: плейсхолдеры Ч1–Ч9 (обкатка после встречи)"
  [ -f "$CHECKLIST" ] || { err "нет $CHECKLIST"; return; }
  grep -q "после встречи" "$CHECKLIST" && ok "шапка: обкатка после встречи на данных мейкера" \
    || err "в CHECKLIST нет пометки «после встречи»"
  local n id
  for n in 1 2 3 4 5 6 7 8 9; do
    id="Ч$n"
    local row
    row=$(awk -F'|' -v id="$id" '{ t=$2; gsub(/ /, "", t); if (t == id) { print; exit } }' "$CHECKLIST")
    if [ -z "$row" ]; then
      err "сценарий $id не найден в CHECKLIST.md"
      continue
    fi
    case "$row" in
      *"["*"]"*) ok "$id: строка-плейсхолдер на месте" ;;
      *) err "$id: строка без чекбокса" ;;
    esac
  done
  local unchecked; unchecked=$(grep -cE '\| \[ \] \|' "$CHECKLIST" || true)
  ok "пустых плейсхолдеров [ ]: $unchecked (до встречи ожидаются все 9)"
}

MODE="${1:-}"
case "$MODE" in
  "")
    basic_checks
    ;;
  --skill)
    basic_checks; skill_checks
    ;;
  --agents)
    basic_checks; agents_checks
    ;;
  --install)
    basic_checks; install_checks
    ;;
  --algorithm)
    basic_checks; algorithm_diff_checks
    ;;
  --install-home)
    basic_checks; install_home_checks
    ;;
  --checklist)
    basic_checks; checklist_checks
    ;;
  --full)
    basic_checks
    skill_checks
    agents_checks
    install_checks
    algorithm_diff_checks
    install_home_checks
    checklist_checks
    ;;
  *)
    echo "ERROR: неизвестный флаг: $MODE" >&2
    echo "Использование: smoke.sh [--skill|--agents|--install|--algorithm|--install-home|--checklist|--full]" >&2
    exit 2
    ;;
esac

if [ "$ERRORS" -gt 0 ]; then
  echo "SMOKE: FAILED ($ERRORS ошибок)" >&2
  exit 1
fi
echo "SMOKE: OK"
