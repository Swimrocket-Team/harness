#!/usr/bin/env bash
#
# smoke.sh — smoke-гейт скилла sr-copywriter (план 05-10). Запуск из корня репо
# SwimRocket (или из бандла — корни вычисляются).
#
# Флаги:
#   (без флагов)   базовый набор: структура скилла (SKILL/algorithm/AGENTS/
#                  ONBOARDING/README-СТАРТ/install×2/update/VERSION/
#                  style×4/kb×7/scripts/sr-sync.sh)
#   --skill        + frontmatter SKILL.md, четыре режима, анти-галлюцинации,
#                  STATE_ROOT, периметр «публикация — человек»
#   --scripts      + bash -n скриптов, пути замены sr-sync, без секретов
#   --install      + install.sh: только sr-copywriter (негативный grep),
#                   --uninstall, install.command/update.command исполняемые
#   --install-home + изолированный HOME (mktemp): install → структура →
#                   5 агентов → идемпотентен → uninstall чистит, журнал остаётся
#   --live         + факт-проверки: «ЧЕРНОВИК» в algorithm, [НУЖЕН ФАКТ] в SKILL
#                   и style, BLOG-PATTERNS из реального блога (адрес+замеры),
#                   CONTENT-PLAN-SEEDS ≥ 20 тем, sr-sync fail-путь и путь
#                   замены (file://-архив)
#   --router       + маршрутизатор 5 скиллов в AGENTS.md и README-МАРШРУТ.md
#   --checklist    + CHECKLIST.md: плейсхолдеры К1–К6 (до встречи — пустые [ ])
#   --full         всё выше
#
# Путь состояния: env SR_STATE_ROOT (для тестов подставляется временный каталог),
# по умолчанию ~/.sr-harness/sr-copywriter.

set -euo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SELF_DIR/.." && pwd)"
REPO_ROOT="$(cd "$SKILL_DIR/../../.." && pwd)"

# Агенты/маршрутизатор: в репо — managers/agents, в бандле — agents/ рядом с skills/
# (README-МАРШРУТ.md в бандле лежит в корне, рядом с agents/ — ищем в обоих местах).
if [ -d "$REPO_ROOT/managers/agents" ]; then
  AGENTS_DIR="$REPO_ROOT/managers/agents"
elif [ -d "$SKILL_DIR/../../agents" ]; then
  AGENTS_DIR="$(cd "$SKILL_DIR/../../agents" && pwd)"
else
  AGENTS_DIR=""
fi
ROUTER_MD=""
if [ -n "$AGENTS_DIR" ] && [ -f "$AGENTS_DIR/README-МАРШРУТ.md" ]; then
  ROUTER_MD="$AGENTS_DIR/README-МАРШРУТ.md"
elif [ -f "$SKILL_DIR/../../README-МАРШРУТ.md" ]; then
  ROUTER_MD="$(cd "$SKILL_DIR/../.." && pwd)/README-МАРШРУТ.md"
fi
CHECKLIST="$SKILL_DIR/tests/CHECKLIST.md"

ERRORS=0
ok()  { echo "  ok: $1"; }
err() { echo "  FAIL: $1" >&2; ERRORS=$((ERRORS + 1)); }
header() { echo "== $1 =="; }

basic_checks() {
  header "базовый набор (структура скилла)"
  local f
  for f in SKILL.md algorithm.md AGENTS.md ONBOARDING.md README-СТАРТ.md \
           install.sh install.command update.command VERSION \
           style/README-СТИЛЬ.md style/article-template.md \
           style/BLOG-PATTERNS.md style/CONTENT-PLAN-SEEDS.md \
           scripts/sr-sync.sh; do
    [ -f "$SKILL_DIR/$f" ] && ok "$f" || err "нет $f"
  done
  [ -f "$SKILL_DIR/tests/smoke.sh" ] && ok "tests/smoke.sh" || err "нет tests/smoke.sh"
  local n_kb; n_kb=$(ls "$SKILL_DIR/kb"/*.md 2>/dev/null | wc -l | tr -d ' ')
  [ "$n_kb" = "7" ] && ok "kb/ — 7 файлов" || err "kb/ — файлов: $n_kb (нужно 7)"
}

skill_checks() {
  header "--skill"
  local fm="$SKILL_DIR/SKILL.md"
  grep -q '^name: sr-copywriter' "$fm" && ok "frontmatter name: sr-copywriter" || err "frontmatter без name: sr-copywriter"
  grep -q '^description:' "$fm" && ok "frontmatter description" || err "frontmatter без description"
  grep -q '^allowed-tools:' "$fm" && ok "frontmatter allowed-tools" || err "frontmatter без allowed-tools"
  local w
  for w in "«статья»" "«серия»" "«редактура»" "«итог»" "НУЖЕН ФАКТ" "article-template" \
           "README-СТИЛЬ" "BLOG-PATTERNS" "CONTENT-PLAN-SEEDS" "sr-harness/sr-copywriter" \
           "150–160"; do
    grep -q "$w" "$fm" && ok "SKILL.md содержит «${w}»" || err "SKILL.md без «${w}»"
  done
  # периметр: публикация — человек, ЕРИД — напоминание
  grep -q "Ноль автопубликаций\|публикация только человеком\|публикация — человек" "$fm" \
    && ok "SKILL: публикация — только человек" || err "SKILL: нет периметра публикации"
  grep -q "ЕРИД" "$fm" && ok "SKILL: ЕРИД — напоминание (юрзона — человек)" \
    || err "SKILL: нет упоминания ЕРИД"
  grep -q "публикуешь" "$SKILL_DIR/README-СТАРТ.md" \
    && ok "README-СТАРТ: публикация — человек («публикуешь сама»)" \
    || err "README-СТАРТ: нет периметра «публикуешь сама»"
}

scripts_checks() {
  header "--scripts"
  bash -n "$SKILL_DIR/scripts/sr-sync.sh" && ok "sr-sync.sh: синтаксис валиден" || err "sr-sync.sh: синтаксис сломан"
  grep -q "SR_HARNESS_REPO_URL" "$SKILL_DIR/scripts/sr-sync.sh" \
    && ok "sr-sync.sh: вшитая константа SR_HARNESS_REPO_URL" || err "sr-sync.sh: нет SR_HARNESS_REPO_URL"
  if grep -E "sr-sync.sh" "$SKILL_DIR/scripts/sr-sync.sh" | grep -qE "token|TOKEN|ghp_|секрет"; then
    err "sr-sync.sh: похоже, есть секреты"
  else
    ok "sr-sync.sh: без секретов (публичный URL, токен не нужен)"
  fi
  grep -q 'sr-copywriter.zip' "$SKILL_DIR/scripts/sr-sync.sh" \
    && ok "sr-sync.sh: качает sr-copywriter.zip" || err "sr-sync.sh: не тот архив"
  grep -q 'Swimrocket-Team/harness' "$SKILL_DIR/scripts/sr-sync.sh" \
    && ok "sr-sync.sh: командное репо Swimrocket-Team/harness" \
    || err "sr-sync.sh: не указано командное репо"
  grep -q 'skills/sr-copywriter/scripts/sr-sync.sh' "$SKILL_DIR/update.command" \
    && ok "update.command: знает бандл-раскладку (skills/sr-copywriter/scripts/)" \
    || err "update.command: нет бандл-раскладки"
}

install_checks() {
  header "--install"
  bash -n "$SKILL_DIR/install.sh" && ok "install.sh: синтаксис валиден" || err "install.sh: синтаксис сломан"
  grep -q "sr-copywriter" "$SKILL_DIR/install.sh" && ok "install.sh про sr-copywriter" \
    || err "install.sh не упоминает sr-copywriter"
  # негативный grep: установщик не знает других скиллов — только свои пути
  if grep -qE "sr-reputation|sr-content-day|sr-content-plan|sr-design" "$SKILL_DIR/install.sh"; then
    err "install.sh упоминает чужие скиллы (должен ставить только sr-copywriter)"
  else
    ok "install.sh без чужих путей (только sr-copywriter)"
  fi
  grep -q -- "--uninstall" "$SKILL_DIR/install.sh" && ok "install.sh: есть --uninstall" \
    || err "install.sh без --uninstall"
  [ -x "$SKILL_DIR/install.command" ] && ok "install.command исполняемый" \
    || err "install.command не исполняемый (нужен chmod +x)"
  [ -x "$SKILL_DIR/update.command" ] && ok "update.command исполняемый" \
    || err "update.command не исполняемый (нужен chmod +x)"
}

install_home_checks() {
  header "--install-home: изолированный HOME"
  local tmp; tmp=$(mktemp -d)
  # install в чистый HOME (репо-раскладка: install.sh внутри скилла)
  if HOME="$tmp" bash "$SKILL_DIR/install.sh" >/dev/null 2>&1; then
    ok "install в чистый HOME прошёл"
  else
    err "install.sh упал в изолированном HOME"
  fi
  [ -f "$tmp/.zcode/skills/sr-copywriter/SKILL.md" ] && ok "~/.zcode/skills/sr-copywriter создан" \
    || err "нет ~/.zcode/skills/sr-copywriter/SKILL.md"
  [ -f "$tmp/.claude/skills/sr-copywriter/style/BLOG-PATTERNS.md" ] \
    && ok "~/.claude/skills/sr-copywriter создан (со style/)" \
    || err "нет ~/.claude/skills/sr-copywriter/style/BLOG-PATTERNS.md"
  [ -f "$tmp/.claude/skills/sr-copywriter/kb/faq.md" ] \
    && ok "kb/ установлены" || err "нет kb/ в установленном"
  [ "$(ls "$tmp/.zcode/agents" 2>/dev/null | wc -l | tr -d ' ')" = "5" ] \
    && [ "$(ls "$tmp/.claude/agents" 2>/dev/null | wc -l | tr -d ' ')" = "5" ] \
    && ok "агентов sr-* по 5 в обоих хостах" || err "агентов в хостах не ровно 5"
  [ -d "$tmp/.sr-harness/sr-copywriter/state/runs" ] \
    && [ -d "$tmp/.sr-harness/sr-copywriter/state/out" ] \
    && ok "STATE_ROOT/state/{runs,out} создана" || err "STATE_ROOT/state/{runs,out} не создана"
  # идемпотентность
  HOME="$tmp" bash "$SKILL_DIR/install.sh" >/dev/null 2>&1 && ok "повторный install безопасен (идемпотентен)" \
    || err "повторный install упал"
  # uninstall чистит, журнал остаётся
  HOME="$tmp" bash "$SKILL_DIR/install.sh" --uninstall >/dev/null 2>&1 || err "uninstall упал"
  [ ! -e "$tmp/.zcode/skills/sr-copywriter" ] && [ ! -e "$tmp/.claude/skills/sr-copywriter" ] \
    && [ ! -e "$tmp/.claude/agents/sr-drafter.md" ] \
    && ok "uninstall снял скилл и агентов" || err "uninstall оставил файлы"
  [ -d "$tmp/.sr-harness/sr-copywriter/state/runs" ] \
    && ok "журнал после uninstall остался (данные не тронуты)" \
    || err "uninstall снёс журнал"
  rm -rf "$tmp"
}

live_checks() {
  header "--live: факт-проверки регламента и стиля"
  # algorithm — черновик-предложение с owner-метками
  grep -q "ЧЕРНОВИК" "$SKILL_DIR/algorithm.md" \
    && ok "algorithm.md: шапка-СТАТУС «ЧЕРНОВИК» (владелец подтверждает на встрече)" \
    || err "algorithm.md: нет пометки ЧЕРНОВИК"
  grep -qE "\[A\]|\[B\]|\[C\]|\[D\]" "$SKILL_DIR/algorithm.md" \
    && ok "algorithm.md: owner-метки шагов [A]/[B]/[C]/[D]" \
    || err "algorithm.md: нет owner-меток"
  # анти-галлюцинации — в SKILL и в style-памятке
  grep -q "НУЖЕН ФАКТ" "$SKILL_DIR/style/README-СТИЛЬ.md" \
    && ok "style/README-СТИЛЬ: правило [НУЖЕН ФАКТ] продублировано" \
    || err "style/README-СТИЛЬ: нет [НУЖЕН ФАКТ]"
  # BLOG-PATTERNS — из реального блога (адрес + замеры живых статей)
  local bp="$SKILL_DIR/style/BLOG-PATTERNS.md"
  grep -q "swimrocket.ru/blog" "$bp" \
    && ok "BLOG-PATTERNS: адрес живого блога (swimrocket.ru/blog)" \
    || err "BLOG-PATTERNS: нет адреса блога"
  grep -q "2026" "$bp" \
    && ok "BLOG-PATTERNS: факт-замеры дат реальных статей (2026)" \
    || err "BLOG-PATTERNS: нет дат замеров"
  # CONTENT-PLAN-SEEDS — не меньше 20 тем
  local n_seeds; n_seeds=$(grep -cE '^[0-9]+\. \*\*' "$SKILL_DIR/style/CONTENT-PLAN-SEEDS.md" || true)
  if [ "${n_seeds:-0}" -ge 20 ]; then
    ok "CONTENT-PLAN-SEEDS: тем ≥ 20 (найдено $n_seeds)"
  else
    err "CONTENT-PLAN-SEEDS: тем всего $n_seeds (нужно ≥ 20)"
  fi
  grep -q "клю" "$SKILL_DIR/style/CONTENT-PLAN-SEEDS.md" \
    && ok "CONTENT-PLAN-SEEDS: у тем есть ключевые фразы" \
    || err "CONTENT-PLAN-SEEDS: нет ключевых фраз"
  # article-template: FAQ и мета-блок на месте
  grep -qi "FAQ" "$SKILL_DIR/style/article-template.md" \
    && ok "article-template: FAQ-секция (у конкурентов блога её нет)" \
    || err "article-template: нет FAQ"
  grep -qi "description" "$SKILL_DIR/style/article-template.md" \
    && ok "article-template: мета-блок (Title/Description)" \
    || err "article-template: нет мета-блока"
  # --- sr-sync: fail-путь и путь замены (изолированный HOME) ---
  local tmp; tmp=$(mktemp -d)
  mkdir -p "$tmp/.zcode/skills/sr-copywriter"
  echo "9.9.9" > "$tmp/.zcode/skills/sr-copywriter/VERSION"
  echo "marker-untouched" > "$tmp/.zcode/skills/sr-copywriter/MARKER"
  local out rc=0
  out="$(HOME="$tmp" SR_SYNC_URL="https://invalid.invalid/x" bash "$SKILL_DIR/scripts/sr-sync.sh" 2>&1)" || rc=$?
  if [ "$rc" = "0" ] && grep -q "не удалось" <<< "$out"; then
    ok "sr-sync fail-путь: exit 0 + честный статус «не удалось / работает старая версия»"
  else
    err "sr-sync fail-путь: rc=$rc или нет слов «не удалось»"
  fi
  [ "$(cat "$tmp/.zcode/skills/sr-copywriter/VERSION")" = "9.9.9" ] \
    && [ -f "$tmp/.zcode/skills/sr-copywriter/MARKER" ] \
    && ok "sr-sync fail-путь: установленное не тронуто" || err "sr-sync fail-путь: скилл изменился"
  # путь замены: «свежий архив» 2.0.0 через file:// (curl умеет file://)
  mkdir -p "$tmp/fakebundle/skills/sr-copywriter"
  cp "$SKILL_DIR/SKILL.md" "$tmp/fakebundle/skills/sr-copywriter/"
  echo "2.0.0" > "$tmp/fakebundle/skills/sr-copywriter/VERSION"
  (cd "$tmp/fakebundle" && zip -qr "$tmp/fake.zip" .) || true
  if [ -f "$tmp/fake.zip" ]; then
    out="$(HOME="$tmp" SR_SYNC_URL="file://$tmp/fake.zip" bash "$SKILL_DIR/scripts/sr-sync.sh" 2>&1)" || rc=$?
    if [ "$rc" = "0" ] && grep -q "обновлено до версии 2.0.0" <<< "$out" \
       && [ "$(cat "$tmp/.zcode/skills/sr-copywriter/VERSION")" = "2.0.0" ]; then
      ok "sr-sync путь замены: скилл обновлён до версии из архива (2.0.0)"
    else
      err "sr-sync путь замены: rc=$rc, VERSION=$(cat "$tmp/.zcode/skills/sr-copywriter/VERSION" 2>/dev/null)"
    fi
  else
    err "sr-sync: тестовая сборка fake.zip не удалась"
  fi
  rm -rf "$tmp"
}

router_checks() {
  header "--router: маршрутизатор 5 скиллов"
  local am="$SKILL_DIR/AGENTS.md"
  grep -qi "маршрутизатор" "$am" && ok "AGENTS.md: раздел маршрутизатора" || err "AGENTS.md: нет раздела «Маршрутизатор»"
  local s
  for s in sr-reputation sr-content-day sr-content-plan sr-design sr-copywriter; do
    grep -q "/$s" "$am" && ok "AGENTS.md: маршрут на /$s" || err "AGENTS.md: нет маршрута на /$s"
  done
  grep -q "не уверена" "$am" && ok "AGENTS.md: фраза «если не уверена — опиши задачу словами»" \
    || err "AGENTS.md: нет фразы «не уверена»"
  if [ -n "$ROUTER_MD" ]; then
    ok "README-МАРШРУТ.md на месте ($ROUTER_MD)"
    local r
    for r in sr-reputation sr-content-day sr-content-plan sr-design sr-copywriter update.command; do
      grep -q "$r" "$ROUTER_MD" && ok "README-МАРШРУТ: упоминает $r" \
        || err "README-МАРШРУТ: нет $r"
    done
  else
    err "нет README-МАРШРУТ.md (managers/agents или корень бандла)"
  fi
}

checklist_checks() {
  header "--checklist: плейсхолдеры К1–К6 (обкатка после встречи)"
  [ -f "$CHECKLIST" ] || { err "нет $CHECKLIST"; return; }
  grep -q "после встречи" "$CHECKLIST" && ok "шапка: обкатка после встречи на реальных материалах" \
    || err "в CHECKLIST нет пометки «после встречи»"
  local n id
  for n in 1 2 3 4 5 6; do
    id="К$n"
    local row
    row=$(awk -F'|' -v id="$id" '{ t=$2; gsub(/ /, "", t); if (t == id) { print; exit } }' "$CHECKLIST")
    if [ -z "$row" ]; then
      err "сценарий $id не найден в CHECKLIST.md"
      continue
    fi
    case "$row" in
      *"["*"]"*) ok "$id: строка-плейсхолдер на месте" ;;
      *) err "$id: строка без чекбокса" ;;
    esac
  done
  grep -q "контент-план" "$CHECKLIST" && grep -q "ключи" "$CHECKLIST" \
    && ok "CHECKLIST: «что принести» (темы контент-плана, ключи)" \
    || err "CHECKLIST: нет «что принести» (темы/ключи)"
}

MODE="${1:-}"
case "$MODE" in
  "")
    basic_checks
    ;;
  --skill)
    basic_checks; skill_checks
    ;;
  --scripts)
    basic_checks; scripts_checks
    ;;
  --install)
    basic_checks; install_checks
    ;;
  --install-home)
    basic_checks; install_home_checks
    ;;
  --live)
    basic_checks; live_checks
    ;;
  --router)
    basic_checks; router_checks
    ;;
  --checklist)
    basic_checks; checklist_checks
    ;;
  --full)
    basic_checks
    skill_checks
    scripts_checks
    install_checks
    install_home_checks
    live_checks
    router_checks
    checklist_checks
    ;;
  *)
    echo "ERROR: неизвестный флаг: $MODE" >&2
    echo "Использование: smoke.sh [--skill|--scripts|--install|--install-home|--live|--router|--checklist|--full]" >&2
    exit 2
    ;;
esac

if [ "$ERRORS" -gt 0 ]; then
  echo "SMOKE: FAILED ($ERRORS ошибок)" >&2
  exit 1
fi
echo "SMOKE: OK"
