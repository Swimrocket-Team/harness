#!/usr/bin/env bash
#
# smoke.sh — структурный smoke-гейт скилла sr-content-plan (план 05-08).
# Запуск из корня репо SwimRocket (или из бандла — корни вычисляются).
#
# Флаги:
#   (без флагов)     базовый набор: структура скилла (SKILL/algorithm/AGENTS/ONBOARDING/
#                    README/install/update/sr-sync/VERSION/kb×7)
#   --skill          + frontmatter SKILL.md, режимы «месяц»/«пункт N»/«итог», журнал,
#                    «когда что», юрзона-напоминания, периметр, AGENTS.md (6 разделов + people)
#   --agents         все 5 агентов sr-*: name/description/tools/model:inherit,
#                    анти-галлюцинационный контракт, need_input, tools без mcp__ (NFR-5.2)
#   --install        install.sh: bash -n, ставит только sr-content-plan (негативный grep),
#                    install.command/update.command на месте и исполняемые
#   --algorithm      algorithm.md = шапка-провенанс + ДОСЛОВНАЯ копия снапшота 05
#                    (diff тела с managers/algorithms/05-content-manager.md пуст)
#   --sync           sr-sync: bash -n (скилл), fail-путь в изолированном HOME
#                    (exit 0 + «не удалось» + установленное не тронуто), путь замены
#                    версии через file://-архив, update.command находит sr-sync
#   --install-home   изолированный HOME (mktemp): install → структура на месте →
#                    идемпотентен → uninstall чистит, журнал остаётся
#   --checklist      CHECKLIST.md: плейсхолдеры Ч1–Ч10 (до встречи — пустые [ ])
#   --full           всё выше
#
# Путь состояния: env SR_STATE_ROOT (для тестов подставляется временный каталог),
# по умолчанию ~/.sr-harness/sr-content-plan.

set -euo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SELF_DIR/.." && pwd)"
REPO_ROOT="$(cd "$SKILL_DIR/../../.." && pwd)"

# Агенты: в репо — managers/agents, в бандле — agents/ рядом с skills/.
if [ -d "$REPO_ROOT/managers/agents" ]; then
  AGENTS_DIR="$REPO_ROOT/managers/agents"
elif [ -d "$SKILL_DIR/../../agents" ]; then
  AGENTS_DIR="$(cd "$SKILL_DIR/../../agents" && pwd)"
else
  AGENTS_DIR=""
fi
SNAPSHOT="$REPO_ROOT/managers/algorithms/05-content-manager.md"
CHECKLIST="$SKILL_DIR/tests/CHECKLIST.md"

ERRORS=0
ok()  { echo "  ok: $1"; }
err() { echo "  FAIL: $1" >&2; ERRORS=$((ERRORS + 1)); }
header() { echo "== $1 =="; }

kb_count() {
  [ -d "$SKILL_DIR/kb" ] && find "$SKILL_DIR/kb" -maxdepth 1 -name '*.md' | wc -l | tr -d ' ' || echo 0
}

basic_checks() {
  header "базовый набор (структура скилла)"
  [ -f "$SKILL_DIR/SKILL.md" ] && ok "SKILL.md" || err "нет SKILL.md"
  [ -f "$SKILL_DIR/algorithm.md" ] && ok "algorithm.md" || err "нет algorithm.md"
  [ -f "$SKILL_DIR/AGENTS.md" ] && ok "AGENTS.md" || err "нет AGENTS.md"
  [ -f "$SKILL_DIR/ONBOARDING.md" ] && ok "ONBOARDING.md" || err "нет ONBOARDING.md"
  [ -f "$SKILL_DIR/README-СТАРТ.md" ] && ok "README-СТАРТ.md" || err "нет README-СТАРТ.md"
  [ -f "$SKILL_DIR/install.sh" ] && ok "install.sh" || err "нет install.sh"
  [ -f "$SKILL_DIR/install.command" ] && ok "install.command" || err "нет install.command"
  [ -f "$SKILL_DIR/update.command" ] && ok "update.command" || err "нет update.command"
  [ -f "$SKILL_DIR/scripts/sr-sync.sh" ] && ok "scripts/sr-sync.sh" || err "нет scripts/sr-sync.sh"
  [ -f "$SKILL_DIR/VERSION" ] && ok "VERSION" || err "нет VERSION"
  local n; n=$(kb_count)
  [ "$n" = "7" ] && ok "kb/ содержит 7 файлов" || err "kb/ содержит $n файлов (нужно 7)"
}

skill_checks() {
  header "--skill"
  local fm="$SKILL_DIR/SKILL.md"
  grep -q '^name: sr-content-plan' "$fm" && ok "frontmatter name: sr-content-plan" || err "frontmatter без name: sr-content-plan"
  grep -q '^description:' "$fm" && ok "frontmatter description" || err "frontmatter без description"
  grep -q '^allowed-tools:' "$fm" && ok "frontmatter allowed-tools" || err "frontmatter без allowed-tools"
  grep -q 'Agent' "$fm" && ok "allowed-tools содержит Agent" || err "allowed-tools без Agent"
  grep -q 'AskUserQuestion' "$fm" && ok "allowed-tools содержит AskUserQuestion" || err "allowed-tools без AskUserQuestion"
  local w
  for w in "«месяц»" "«пункт N»" "«итог»" run_mode operator revision checker need_input \
           "sr-harness/sr-content-plan" "когда что" "Частотная карта" \
           "черновик — публикуешь/отправляешь сам" "Ноль публикаций без апрува"; do
    # ${w} в фигурных скобках обязательно: bash 5.3 читает $w» как переменную «w»»
    grep -q "$w" "$fm" && ok "SKILL.md содержит «${w}»" || err "SKILL.md без «${w}»"
  done
  # 28 пунктов покрываются режимом «пункт N»: таблица 1..28
  local p missing=0
  for p in $(seq 1 28); do
    grep -qE "^\| $p \|" "$fm" || { err "в таблице «пункт N» нет строки | $p |"; missing=1; }
  done
  [ "$missing" = "0" ] && ok "таблица «пункт N» покрывает 1–28"
  # юрзона: маркировка/ЕРИД, РКН, деньги — только напоминания
  grep -q "Пункты 3–4 (маркировка рекламы/ОРД/ЕРИД, РКН) — юрзона, финал всегда человек" "$fm" \
    && ok "SKILL.md: маркировка/ЕРИД — юрзона (напоминание)" \
    || err "SKILL.md: нет юрзоны по п.3–4 (маркировка/ЕРИД/РКН)"
  grep -q "Деньги, ЕРИД/маркировка, РКН — всегда человек" "$fm" \
    && ok "SKILL.md: деньги — человек" || err "SKILL.md: нет строки «Деньги, ЕРИД/маркировка, РКН — всегда человек»"
  grep -q "2/16/26" "$fm" && ok "SKILL.md: денежные пункты 2/16/26 помечены" \
    || err "SKILL.md: нет пометки денежных пунктов 2/16/26"
  # AGENTS.md: 6 разделов методички + people-карта (9 имён)
  local ag="$SKILL_DIR/AGENTS.md" who
  local section_ok=1
  for section in "Твой человек" "Проект и рабочая папка" "Как работать" "Что учитывать" "Ограничения" "Формат ответа"; do
    grep -q "^## $section" "$ag" || { err "AGENTS.md без раздела «$section»"; section_ok=0; }
  done
  [ "$section_ok" = "1" ] && ok "AGENTS.md: все 6 разделов методички"
  for who in РОМ Соня Аня Женя Даша Альберт Никита Полина Катя; do
    grep -q "$who" "$ag" && ok "AGENTS.md: people-карта — $who" || err "AGENTS.md: нет $who в people-карте"
  done
  grep -q "маркировк" "$ag" && ok "AGENTS.md: юрзона в Ограничениях" || err "AGENTS.md: нет юрзоны"
  # журнал-схема: algorithm: content-manager
  grep -q '"algorithm": "content-manager"' "$fm" && ok "журнал: algorithm=content-manager" \
    || err "SKILL.md: в схеме журнала нет \"algorithm\": \"content-manager\""
  # периметр: кабинеты — человек; длина README ≤ 1 страницы
  grep -q "Кабинеты и сервисы — только человек" "$fm" \
    && ok "SKILL.md: кабинеты — человек" || err "SKILL.md: нет строки «Кабинеты и сервисы — только человек»"
  local readme_lines; readme_lines=$(wc -l < "$SKILL_DIR/README-СТАРТ.md" | tr -d ' ')
  [ "$readme_lines" -le 40 ] && ok "README-СТАРТ.md ≤ 1 страницы ($readme_lines строк)" \
    || err "README-СТАРТ.md слишком длинный: $readme_lines строк"
  grep -q "update.command" "$SKILL_DIR/README-СТАРТ.md" \
    && ok "README-СТАРТ.md: упоминает обновление (update.command)" \
    || err "README-СТАРТ.md: нет строки про обновление update.command"
}

agents_checks() {
  header "--agents"
  if [ -z "$AGENTS_DIR" ] || [ ! -d "$AGENTS_DIR" ]; then
    err "не найдена папка агентов (managers/agents или agents/ рядом с skills/)"; return
  fi
  local agents=(sr-drafter sr-editor sr-data-filler sr-checker sr-reporter)
  local found=0 a f
  for a in "${agents[@]}"; do
    f="$AGENTS_DIR/$a.md"
    if [ ! -f "$f" ]; then
      err "нет $a.md в $AGENTS_DIR"
      continue
    fi
    found=$((found + 1))
    grep -q "^name: $a" "$f" && ok "$a: name" || err "$a: frontmatter без name"
    grep -q '^description:' "$f" && ok "$a: description" || err "$a: frontmatter без description"
    grep -q '^tools:' "$f" && ok "$a: tools" || err "$a: frontmatter без tools"
    grep -q '^model: inherit' "$f" && ok "$a: model: inherit" || err "$a: без model: inherit"
    grep -q 'Не выдумывать ссылки, ID, цены, даты' "$f" \
      && ok "$a: анти-галлюцинационный контракт" \
      || err "$a: нет строки контракта «Не выдумывать ссылки, ID, цены, даты»"
    grep -q 'need_input' "$f" && ok "$a: need_input" || err "$a: без правила need_input"
    if grep '^tools:' "$f" | grep -q 'mcp__'; then
      err "$a: в tools есть mcp__ (запрещено NFR-5.2)"
    else
      ok "$a: tools без mcp__"
    fi
  done
  [ "$found" -eq 5 ] && ok "агентов ровно 5" || err "найдено агентов: $found (нужно 5)"
}

install_checks() {
  header "--install"
  bash -n "$SKILL_DIR/install.sh" && ok "install.sh: синтаксис валиден" || err "install.sh: синтаксис сломан"
  grep -q "sr-content-plan" "$SKILL_DIR/install.sh" && ok "install.sh про sr-content-plan" \
    || err "install.sh не упоминает sr-content-plan"
  # негативный grep: установщик не знает других скиллов — только свои пути
  if grep -q "sr-reputation" "$SKILL_DIR/install.sh"; then
    err "install.sh упоминает sr-reputation (должен ставить только sr-content-plan)"
  else
    ok "install.sh без чужих путей (только sr-content-plan)"
  fi
  [ -x "$SKILL_DIR/install.command" ] && ok "install.command исполняемый" \
    || err "install.command не исполняемый (нужен chmod +x)"
  [ -x "$SKILL_DIR/update.command" ] && ok "update.command исполняемый" \
    || err "update.command не исполняемый (нужен chmod +x)"
  grep -q -- "--uninstall" "$SKILL_DIR/install.sh" && ok "install.sh: есть --uninstall" \
    || err "install.sh без --uninstall"
  # VERSION в обоих скиллах (единая модель обновления)
  [ -f "$REPO_ROOT/managers/skills/sr-reputation/VERSION" ] \
    && ok "sr-reputation: VERSION на месте" \
    || err "нет managers/skills/sr-reputation/VERSION"
  [ -f "$REPO_ROOT/managers/skills/sr-reputation/update.command" ] \
    && ok "sr-reputation: update.command на месте" \
    || err "нет managers/skills/sr-reputation/update.command"
  [ -f "$REPO_ROOT/managers/skills/sr-reputation/scripts/sr-sync.sh" ] \
    && ok "sr-reputation: scripts/sr-sync.sh на месте" \
    || err "нет managers/skills/sr-reputation/scripts/sr-sync.sh"
}

algorithm_diff_checks() {
  header "--algorithm: дословность снапшота 05"
  [ -f "$SNAPSHOT" ] || { err "нет снапшота $SNAPSHOT"; return; }
  local first_line; first_line=$(head -n 1 "$SKILL_DIR/algorithm.md")
  case "$first_line" in
    "<!--"*) ok "шапка-провенанс на месте (строка 1 — HTML-комментарий)" ;;
    *) err "первая строка algorithm.md не провенанс: $first_line" ;;
  esac
  # поиск по СТРОКЕ (here-string), а не по файлу с именем из строки
  grep -q "контент-менеджер" <<< "$first_line" && ok "провенанс: владелец — контент-менеджер (имя уточнить)" \
    || err "в провенансе нет владельца «контент-менеджер»"
  # тело: от первого "^1)" до конца файла == снапшот от "^1) Ежемесячная" до конца
  local body_start
  body_start=$(grep -n "^1)" "$SKILL_DIR/algorithm.md" | head -1 | cut -d: -f1)
  [ -n "$body_start" ] || { err "в algorithm.md нет строки, начинающейся с «1)»"; return; }
  if diff <(tail -n +"$body_start" "$SKILL_DIR/algorithm.md") \
          <(grep -A100000 "^1) Ежемесячная" "$SNAPSHOT") >/dev/null 2>&1; then
    ok "тело algorithm.md дословно совпадает со снапшотом 05 (diff пуст)"
  else
    err "тело algorithm.md отличается от managers/algorithms/05-content-manager.md"
  fi
}

sync_checks() {
  header "--sync: sr-sync fail-путь и путь замены (изолированный HOME)"
  bash -n "$SKILL_DIR/scripts/sr-sync.sh" && ok "sr-sync.sh: синтаксис валиден" \
    || err "sr-sync.sh: синтаксис сломан"
  grep -q "SR_HARNESS_REPO_URL" "$SKILL_DIR/scripts/sr-sync.sh" \
    && ok "sr-sync.sh: вшитая константа SR_HARNESS_REPO_URL" \
    || err "sr-sync.sh: нет SR_HARNESS_REPO_URL"
  if grep -E "sr-sync.sh" "$SKILL_DIR/scripts/sr-sync.sh" | grep -qE "token|TOKEN|ghp_|секрет"; then
    err "sr-sync.sh: похоже, есть секреты"
  else
    ok "sr-sync.sh: без секретов (публичный URL, токен не нужен)"
  fi
  # update.command находит sr-sync.sh в обеих раскладках (паттерн путей в скрипте)
  grep -q 'scripts/sr-sync.sh' "$SKILL_DIR/update.command" \
    && ok "update.command: ссылается на scripts/sr-sync.sh" \
    || err "update.command: не находит sr-sync.sh"
  grep -q "skills/sr-content-plan/scripts/sr-sync.sh" "$SKILL_DIR/update.command" \
    && ok "update.command: знает бандл-раскладку (skills/sr-content-plan/scripts/)" \
    || err "update.command: нет бандл-раскладки"

  local tmp; tmp=$(mktemp -d)
  local errors_before=$ERRORS

  # 1) fail-путь: недоступный URL → exit 0, честный статус, установленное не тронуто
  mkdir -p "$tmp/.zcode/skills/sr-content-plan"
  echo "9.9.9" > "$tmp/.zcode/skills/sr-content-plan/VERSION"
  echo "marker-untouched" > "$tmp/.zcode/skills/sr-content-plan/MARKER"
  local out rc=0
  out="$(HOME="$tmp" SR_SYNC_URL="https://invalid.invalid/x" bash "$SKILL_DIR/scripts/sr-sync.sh" 2>&1)" || rc=$?
  if [ "$rc" = "0" ] && grep -q "не удалось" <<< "$out"; then
    ok "fail-путь: exit 0 + честный статус «не удалось / работает старая версия»"
  else
    err "fail-путь: rc=$rc или нет слов «не удалось» (вывод: ${out:0:120})"
  fi
  if [ "$(cat "$tmp/.zcode/skills/sr-content-plan/VERSION")" = "9.9.9" ] \
     && [ -f "$tmp/.zcode/skills/sr-content-plan/MARKER" ]; then
    ok "fail-путь: установленное не тронуто (VERSION и файлы на месте)"
  else
    err "fail-путь: установленный скилл изменился"
  fi

  # 2) путь замены: «свежий архив» с версией 2.0.0 через file:// (curl умеет file://)
  mkdir -p "$tmp/fakebundle/skills/sr-content-plan"
  cp "$SKILL_DIR/SKILL.md" "$SKILL_DIR/algorithm.md" "$tmp/fakebundle/skills/sr-content-plan/"
  echo "2.0.0" > "$tmp/fakebundle/skills/sr-content-plan/VERSION"
  (cd "$tmp/fakebundle" && zip -qr "$tmp/fake.zip" .) || true
  [ -f "$tmp/fake.zip" ] || err "тестовая сборка fake.zip не удалась"
  if [ -f "$tmp/fake.zip" ]; then
    out="$(HOME="$tmp" SR_SYNC_URL="file://$tmp/fake.zip" bash "$SKILL_DIR/scripts/sr-sync.sh" 2>&1)" || rc=$?
    if [ "$rc" = "0" ] && grep -q "обновлено до версии 2.0.0" <<< "$out" \
       && [ "$(cat "$tmp/.zcode/skills/sr-content-plan/VERSION")" = "2.0.0" ]; then
      ok "путь замены: скилл обновлён до версии из архива (2.0.0)"
    else
      err "путь замены: rc=$rc, VERSION=$(cat "$tmp/.zcode/skills/sr-content-plan/VERSION" 2>/dev/null)"
    fi
    # 3) --check без замены
    echo "3.0.0" > "$tmp/fakebundle/skills/sr-content-plan/VERSION"
    (cd "$tmp/fakebundle" && zip -qr "$tmp/fake2.zip" .) || true
    out="$(HOME="$tmp" SR_SYNC_URL="file://$tmp/fake2.zip" bash "$SKILL_DIR/scripts/sr-sync.sh" --check 2>&1)" || rc=$?
    if [ "$rc" = "0" ] && grep -q "Доступно обновление" <<< "$out" \
       && [ "$(cat "$tmp/.zcode/skills/sr-content-plan/VERSION")" = "2.0.0" ]; then
      ok "--check: сравнил версии и ничего не менял (2.0.0 осталась)"
    else
      err "--check: rc=$rc, VERSION=$(cat "$tmp/.zcode/skills/sr-content-plan/VERSION" 2>/dev/null)"
    fi
    # 4) та же версия → no-op
    out="$(HOME="$tmp" SR_SYNC_URL="file://$tmp/fake.zip" bash "$SKILL_DIR/scripts/sr-sync.sh" 2>&1)" || rc=$?
    if [ "$rc" = "0" ] && grep -q "уже последняя версия" <<< "$out"; then
      ok "та же версия: «уже последняя», замены нет"
    else
      err "та же версия: rc=$rc или нет статуса «уже последняя версия»"
    fi
  fi
  rm -rf "$tmp"
  [ "$ERRORS" = "$errors_before" ] || true
}

install_home_checks() {
  header "--install-home: изолированный HOME"
  local tmp; tmp=$(mktemp -d)
  local errors_before=$ERRORS
  # install в чистый HOME (репо-раскладка: install.sh внутри скилла)
  if HOME="$tmp" bash "$SKILL_DIR/install.sh" >/dev/null 2>&1; then
    ok "install в чистый HOME прошёл"
  else
    err "install.sh упал в изолированном HOME"
  fi
  [ -f "$tmp/.zcode/skills/sr-content-plan/SKILL.md" ] && ok "~/.zcode/skills/sr-content-plan создан" \
    || err "нет ~/.zcode/skills/sr-content-plan/SKILL.md"
  [ -f "$tmp/.claude/skills/sr-content-plan/algorithm.md" ] && ok "~/.claude/skills/sr-content-plan создан" \
    || err "нет ~/.claude/skills/sr-content-plan/algorithm.md"
  [ "$(ls "$tmp/.zcode/agents" 2>/dev/null | wc -l | tr -d ' ')" = "5" ] \
    && [ "$(ls "$tmp/.claude/agents" 2>/dev/null | wc -l | tr -d ' ')" = "5" ] \
    && ok "агентов sr-* по 5 в обоих хостах" || err "агентов в хостах не ровно 5"
  [ -d "$tmp/.sr-harness/sr-content-plan/state/runs" ] \
    && [ -d "$tmp/.sr-harness/sr-content-plan/state/out" ] \
    && ok "журнал-директория STATE_ROOT/state/{runs,out} создана" \
    || err "STATE_ROOT/state/{runs,out} не создана"
  # идемпотентность
  HOME="$tmp" bash "$SKILL_DIR/install.sh" >/dev/null 2>&1 && ok "повторный install безопасен (идемпотентен)" \
    || err "повторный install упал"
  # uninstall чистит, журнал остаётся
  HOME="$tmp" bash "$SKILL_DIR/install.sh" --uninstall >/dev/null 2>&1 || err "uninstall упал"
  [ ! -e "$tmp/.zcode/skills/sr-content-plan" ] && [ ! -e "$tmp/.claude/skills/sr-content-plan" ] \
    && [ ! -e "$tmp/.claude/agents/sr-drafter.md" ] \
    && ok "uninstall снял скилл и агентов" || err "uninstall оставил файлы"
  [ -d "$tmp/.sr-harness/sr-content-plan/state/runs" ] \
    && ok "журнал после uninstall остался (данные не тронуты)" \
    || err "uninstall снёс журнал"
  rm -rf "$tmp"
  [ "$ERRORS" = "$errors_before" ] || true
}

checklist_checks() {
  header "--checklist: плейсхолдеры Ч1–Ч10 (обкатка после встречи)"
  [ -f "$CHECKLIST" ] || { err "нет $CHECKLIST"; return; }
  grep -q "после встречи" "$CHECKLIST" && ok "шапка: обкатка после встречи на данных менеджера" \
    || err "в CHECKLIST нет пометки «после встречи»"
  local n id
  for n in 1 2 3 4 5 6 7 8 9 10; do
    id="Ч$n"
    local row
    row=$(awk -F'|' -v id="$id" '{ t=$2; gsub(/ /, "", t); if (t == id) { print; exit } }' "$CHECKLIST")
    if [ -z "$row" ]; then
      err "сценарий $id не найден в CHECKLIST.md"
      continue
    fi
    case "$row" in
      *"["*"]"*) ok "$id: строка-плейсхолдер на месте" ;;
      *) err "$id: строка без чекбокса" ;;
    esac
  done
  local unchecked; unchecked=$(grep -cE '\| \[ \] \|' "$CHECKLIST" || true)
  ok "пустых плейсхолдеров [ ]: $unchecked (до встречи ожидаются все 10)"
}

MODE="${1:-}"
case "$MODE" in
  "")
    basic_checks
    ;;
  --skill)
    basic_checks; skill_checks
    ;;
  --agents)
    basic_checks; agents_checks
    ;;
  --install)
    basic_checks; install_checks
    ;;
  --algorithm)
    basic_checks; algorithm_diff_checks
    ;;
  --sync)
    basic_checks; sync_checks
    ;;
  --install-home)
    basic_checks; install_home_checks
    ;;
  --checklist)
    basic_checks; checklist_checks
    ;;
  --full)
    basic_checks
    skill_checks
    agents_checks
    install_checks
    algorithm_diff_checks
    sync_checks
    install_home_checks
    checklist_checks
    ;;
  *)
    echo "ERROR: неизвестный флаг: $MODE" >&2
    echo "Использование: smoke.sh [--skill|--agents|--install|--algorithm|--sync|--install-home|--checklist|--full]" >&2
    exit 2
    ;;
esac

if [ "$ERRORS" -gt 0 ]; then
  echo "SMOKE: FAILED ($ERRORS ошибок)" >&2
  exit 1
fi
echo "SMOKE: OK"
