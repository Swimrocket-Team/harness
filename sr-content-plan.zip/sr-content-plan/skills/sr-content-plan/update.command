#!/usr/bin/env bash
#
# update.command — обновление ассистента «Контент-план» двойным кликом (macOS).
# Находит свою папку, запускает scripts/sr-sync.sh из неё и объясняет, что делать
# дальше. Написан человеческим языком: оператор не знает термина.
#
# Работает из двух раскладок:
#   скилл (репо или установленный): рядом scripts/sr-sync.sh
#   бандл: рядом skills/sr-content-plan/scripts/sr-sync.sh

set -u

DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"

SYNC=""
if [ -f "$DIR/scripts/sr-sync.sh" ]; then
  SYNC="$DIR/scripts/sr-sync.sh"
elif [ -f "$DIR/skills/sr-content-plan/scripts/sr-sync.sh" ]; then
  SYNC="$DIR/skills/sr-content-plan/scripts/sr-sync.sh"
fi

echo "Ассистент «Контент-план» — обновление"
echo "-------------------------------------"
echo "Эта программа проверит свежую версию и обновит ассистента."
echo "Твои настройки и журнал не тронутся."

if [ -z "$SYNC" ]; then
  echo ""
  echo "Не нашла программу обновления (sr-sync.sh) рядом с этим файлом."
  echo "Похоже, при распаковке архив распался. Распакуй архив заново:"
  echo "дважды кликни по архиву — появится папка, и запускай update.command из неё."
  echo ""
  echo "Если не получается — напиши Мише."
  echo ""
  read -r -p "Нажми Enter, чтобы закрыть это окно" _
  exit 1
fi

echo ""
bash "$SYNC"
RESULT=$?

echo ""
if [ "$RESULT" = "0" ]; then
  echo "Если выше написано «Готово» или «последняя версия» — всё в порядке, можно работать."
else
  echo "Что-то пошло не так. Напиши Мише и пришли ему то, что напечатано выше."
fi
echo ""
read -r -p "Нажми Enter, чтобы закрыть это окно" _
exit $RESULT
